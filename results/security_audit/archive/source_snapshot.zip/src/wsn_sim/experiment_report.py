from argparse import ArgumentParser
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path

from wsn_sim.config import DEFAULT_CONFIG_PATH
from wsn_sim.experiment_figures import draw_figures
from wsn_sim.experiment_tables import collect_batch, make_tables
from wsn_sim.storage import create_run_directory


def render_report(batch_directory, output_root=None, demo_directory=None):
    root = DEFAULT_CONFIG_PATH.parents[1]
    plan, checkpoint, records = collect_batch(batch_directory, root)
    directory = create_run_directory(output_root or batch_directory / "reports", "report")
    rows, aggregates, completeness, comparisons = make_tables(plan, checkpoint, records, directory)
    figures = draw_figures(plan, records, aggregates, directory, demo_directory)
    complete = len(records)
    failed = sum(row["failed"] for row in completeness)
    expected = plan["expected_runs"]
    counts = {"expected": expected, "completed": complete, "failed": failed, "pending": expected - complete - failed}
    all_complete = complete == expected and all(row["meets_30_independent_seeds"] for row in completeness)
    if plan["scope"] == "TEST_ONLY":
        all_complete = False
    config = plan["base_configuration"]
    complete_configs = sum(row["meets_30_independent_seeds"] for row in completeness)
    table = "\n".join(
        f'| {row["case_id"]} | {row["expected"]} | {row["completed"]} | {row["failed"]} | {row["pending"]} | {"DONE 30 seed" if row["meets_30_independent_seeds"] else "PARTIAL"} |'
        for row in completeness
    )
    links = "\n".join(f'- [{row["figure"]}]({row["figure"]}) · [input CSV]({Path(row["data_csv"]).name})' for row in figures)
    stamp = datetime.now(timezone(timedelta(hours=7), "Asia/Bangkok")).isoformat()
    numerical = "\n".join(
        f'| {row["scenario"]} | {row["metric"]} | {row["n_used"]}/{row["n_expected"]} | {row["mean"]} | {row["ci95_low"]} | {row["ci95_high"]} |'
        for row in aggregates if row["metric"] in {"pdr", "goodput_bps", "energy_per_payload_bit_j", "tpr", "fpr", "coverage"} and (row["rho"] == 0 or (row["rho"] == 0.05 and row["p_drop"] == 0.5)) and row["placement"] == "random"
    )
    text = f"""# Phương pháp, kết quả và nghiệm thu chặng 7–8

Tạo từ dữ liệu thật lúc {stamp}. Batch: {batch_directory}. Scope={plan["scope"]}. Expected/completed/failed/pending={expected}/{complete}/{failed}/{counts["pending"]}. Có {complete_configs}/{len(completeness)} cấu hình đủ tối thiểu 30 seed độc lập. Trạng thái đánh giá toàn ma trận: {"DONE" if all_complete else "PARTIAL, chưa được tuyên bố hoàn tất 30 seed cho mọi cấu hình"}.

## Phương pháp

Mỗi run tạo process và Simulation mới, {config["num_sensors"]} sensor/{config["num_sinks"]} sink trên vùng {config["area_width_m"]}×{config["area_height_m"]} m theo config đã lưu; tọa độ và tập cạnh thực được lưu cùng topology hash. E0={config["initial_energy_j"]} J, Eth={config["energy_threshold_ratio"]}×E0, R={config["communication_range_m"]} m. Pilot R=250/300/350 dùng seed riêng, chọn bằng reachability trước evaluation; topology xấu không bị loại khỏi mẫu số.

Radio dùng E_elec=50 nJ/bit, epsilon_fs=10 pJ/bit/m², epsilon_mp=0.0013 pJ/bit/m⁴, d0=sqrt(epsilon_fs/epsilon_mp). Payload={config["packet_size_bytes"]} byte, wire bằng payload khi không khai báo thêm, Tg={config["packet_interval_s"]} s. Mỗi sensor sống sinh gói; không có tuyến vẫn generated+dropped unreachable. Horizon chính giữ max_rounds={config["max_rounds"]}, tương ứng {config["max_rounds"] * config["packet_interval_s"]} s, hoặc dừng LND. Không thay bằng batch ngắn rồi gọi lifetime đầy đủ.

MHR tối thiểu hop và chỉ loại node chết. EMHR dùng lexicographic hop/distance/E0/(E+epsilon) với ngưỡng relay, ID ổn định khi hòa; sink chỉ là đích. S-EMHR dùng cùng lõi EMHR, loại relay đang cách ly khỏi view, giữ graph vật lý và own-origin policy. Reroute từ current holder, cấm prefix đã đi, ưu tiên sink hiện tại rồi fallback.

Các kịch bản duy nhất: MHR/EMHR benign; MHR_SF/EMHR_SF không phòng vệ; SF2=EMHR có detector nhưng không avoidance; SF3=S-EMHR đầy đủ. EMHR_SF cho phép tách detector khỏi thay đổi routing; không thêm baseline không định nghĩa.

Attacker chỉ chọn sensor, half-up cho rho=2/5/10%, p_drop=0.25/0.5/0.75. Random/near-sink có cùng số lượng; near-sink dựa khoảng cách Euclid tới sink gần nhất rồi ID. Explicit IDs dành debug. Sau successful transit RX mới được selective drop; own packet không bị bỏ. Channel p={config["channel_loss_probability"]} là stream độc lập, loss trước RX không phải selective forwarding.

Observer lý tưởng nhận RX/TX SimPy, success=relay TX chứ không phải next-hop ACK. Detector dùng mature deadline cohort, FR=F/N cùng cohort; pending/own/sink/duplicate không làm failed giả. EWMA beta_trust tách ngưỡng năng lượng. N_min/T<tau/K và probation cần RX mới sau expiry. Tham số nghiên cứu được calibration benign ở p_channel=0/0.01/0.05, protocol/selection/validation và freeze lưu trước evaluation; không xem nhãn attacker hoặc evaluation để đổi ngưỡng.

Sáu RNG namespace và event keys SHA-256 ghép cùng sự kiện giữa thuật toán. Cùng seed giữ tọa độ, traffic, channel variates và tập attacker theo treatment. Source SHA={plan["source_fingerprint"]["sha256"]}; plan hash={plan["plan_hash"]}. Mỗi run lưu config/stream seeds/attacker set/coordinates/hash/dependencies/Git/dirty diff hash/command/status/stop reason/wall/RAM. Không trộn code hoặc config khác hash.

Streaming giữ active Packet và cohort chưa đóng, cộng dồn counters rồi giải phóng terminal history; trace đầy đủ có tùy chọn cho demo. Packet IDs source-sequence và single-path/terminal guard giữ unique trong threat model không MAC replay. Round không tuyến có thể được cộng theo nguồn sống với counter/sequence chính xác, không rút thêm attack/channel variates. Cache chỉ dùng khi nghiệm hop-distance duy nhất hoặc MHR; hòa năng lượng vẫn tính lại. Eligibility/expiry/link changes làm mất hiệu lực cache. Test full/compact bảo toàn kết quả được ghi ở audit chặng 7.

## Thống kê và censoring

Mỗi giá trị chính là một run/seed độc lập; n thực tế, std ddof=1 và coverage có trong aggregate.csv. CI95=mean±t(0.975,n−1)×s/sqrt(n), chỉ có khi n≥2. Không có CI từ một seed, không coi node/window cùng topology là mẫu độc lập. n<30 hoặc run/metric thiếu được đánh dấu; không thay NA bằng zero.

FND/HND/LND chưa thấy là censored, không lấy simulation end làm event. Báo observed/censored coverage trong lifetime_censoring.json. Mean của min(lifetime,horizon) được ghi restricted, không tuyên bố mean lifetime không giới hạn; observed-only mean được đánh dấu conditional. Payload trước milestone thiếu vẫn NA, không được điền 0 để làm biểu đồ đẹp.

Detection/isolation delay chưa phát hiện là censored. Primary delay summary là mean capped delay theo từng seed tại tau chung bằng observation end nhỏ nhất trong treatment family, bao gồm attacker undetected bằng cap. Tau ghi trong runs.csv; đây là restricted estimand, không phải mean chỉ trên node phát hiện. Không xem censoring do chết là độc lập để suy rộng delay vô hạn.

So cặp trên matched seeds, kiểm tra pairing/topology/attacker IDs. Các contrast được khai báo: EMHR_SF–MHR_SF, SF2–EMHR_SF, SF3–SF2, SF3–EMHR_SF và EMHR–MHR benign. Báo paired t-test và Wilcoxon-Pratt, cùng assumption, diagnostic Shapiro và actual matched n; không chọn test có p đẹp hơn. Zero differences cho p=1/effect=0; zero-variance nonzero differences không tạo t-stat giả. Sai khác làm tròn 12 chữ số thập phân cho rank/zero handling.

Effect gồm mean paired difference có đơn vị, Cohen dz khi SD khác 0 và rank-biserial trên nonzero pairs. Holm điều chỉnh toàn family metric×contrast×treatment cho từng loại test; cả mục NA được giữ trong family size. Inference thiếu 30 cặp vẫn descriptive/incomplete, không kết luận thắng thua. Kết quả có censoring/coverage thấp phải đọc cùng PDR và delivered population.

Nguồn thuật toán: [SciPy Student-t](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.t.html), [paired t-test](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ttest_rel.html), [Wilcoxon](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.wilcoxon.html). Không tạo tài liệu tham khảo hoặc kết luận chưa có dữ liệu.

## Kết quả có dữ liệu

Bảng trung tâm rho=5%, p_drop=0.5 (benign ở rho=0); None là NA hoặc pending. Kết luận phải đọc cùng coverage và p đã điều chỉnh trong CSV.

| Scenario | Metric | n used/expected | Mean | CI95 low | CI95 high |
|---|---|---:|---:|---:|---:|
{numerical}

[runs.csv](runs.csv) chứa số đo từng seed; [aggregate.csv](aggregate.csv) chứa mean/std/CI/n/coverage và estimand; [paired_comparisons.csv](paired_comparisons.csv) chứa matched seeds/effects/raw và adjusted p; [lifetime_censoring.json](lifetime_censoring.json) chứa censoring. Không diễn giải PDR/delay/energy theo chiều có lợi trước khi đối chiếu bảng thật.

{links}

Mỗi figure có axes/units/legend/config và input CSV riêng; figure_manifest.json liên kết script, SHA-256 input, configuration và seed list. Alive/energy bands là pointwise 95%, không phải simultaneous bands. Trace FR/trust dùng graph TEST_ONLY một seed, không có CI và không trộn với evaluation. Logical route/security decisions không thay thế overhead giao thức chưa modeled.

## Completeness theo cấu hình

| Cấu hình | Expected | Completed | Failed | Pending | Trạng thái |
|---|---:|---:|---:|---:|---|
{table}

Mở rộng đã kê nhưng chưa tự coi hoàn tất: {json.dumps(plan["extension_pending"], ensure_ascii=False)}. Failed/timeout/retry nằm trong checkpoint attempts và attempt folders, không bỏ âm thầm hoặc đếm lại seed.

## Hạn chế và giả thuyết

Observer ideal không phải overhearing/ACK thực tế; mất kênh sau TX không hạ FR của relay đã phát. Chưa có MAC/queue/ACK/retry/control protocol; control_packets/monitoring energy/time là NA/not_modeled, không tuyên bố chi phí thật bằng 0. Calibration hữu hạn không chứng minh threshold tối ưu hoặc FPR tổng thể 5%, thêm K không tự chứng minh giảm FP.

S-EMHR có thể không còn tuyến thay thế; tránh node có thể tăng hop/energy hoặc giảm reachability. Pin lâu do drop sớm và delay nhỏ trên số ít gói delivered không chứng minh cải thiện. Giả thuyết không đạt hoặc kết quả bất lợi vẫn được giữ. Censoring và nhiều so sánh hạn chế diễn giải; chưa có hai reviewer thật được xác nhận, người dùng sẽ tự review. Chưa push/merge.

## Chạy và resume trên Windows

    Set-Location 'F:\\bangdzaihjhj\\dancctt'
    & '.\\.venv\\Scripts\\python.exe' scripts\\run_experiments.py resume '{batch_directory}' --workers 6
    & '.\\.venv\\Scripts\\python.exe' scripts\\report_experiments.py '{batch_directory}'

Lệnh resume kiểm tra source/plan/config/completion hashes, skip run COMPLETE đúng hash, làm lại attempt dở/hỏng trong thư mục mới. Worker/timeout/retry có giới hạn; chưa chạy unit tests song song batch. Muốn đổi code/config phải tạo batch mới hoặc calibration mới, không cập nhật hash cũ để lách kiểm tra.

## DONE/PARTIAL/BLOCKED

| Hạng mục | Code | 30 seed | Báo cáo |
|---|---|---|---|
| Runner/dry-run/pilot/workers/checkpoint/resume | DONE | không áp dụng | DONE |
| Ma trận chính | DONE | {"DONE" if all_complete else "PARTIAL"} | DONE với số thiếu thật |
| Thống kê/đối chiếu/figure provenance | DONE | {"DONE" if all_complete else "PARTIAL theo n thực tế"} | DONE |
| Mở rộng vị trí/R/Eth/channel | DONE CLI + calibration guard | PARTIAL, xem pending | DONE trạng thái |
| Overhead ACK/MAC/queue thực | chưa modeled | không áp dụng | Giới hạn được công bố |

Không có BLOCKED về kỹ thuật trong các lượt hợp lệ đã ghi; phần chưa chạy là PENDING, không được báo DONE.
"""
    (directory / "METHODS_RESULTS.md").write_text(text, encoding="utf-8")
    status = {"counts": counts, "configurations_meeting_30_seeds": complete_configs, "configurations": len(completeness), "all_main_evaluation_complete": all_complete, "scope": plan["scope"], "figures": len(figures), "output_directory": str(directory)}
    (directory / "report_status.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    print(json.dumps(status, indent=2))
    return status


def main():
    parser = ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--demo-directory", type=Path)
    args = parser.parse_args()
    render_report(args.directory.resolve(), args.output, args.demo_directory)


if __name__ == "__main__":
    main()
