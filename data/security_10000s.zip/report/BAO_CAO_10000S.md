# Hiệu năng và bảo mật WSN trong 10.000 giây

**480/480 lượt; 16 cấu hình × 30 seed; lỗi=0; còn thiếu=0.**

[Dữ liệu từng seed](runs.csv) · [CSV bảo mật](security_runs.csv) · [Trạng thái từng relay](relay_security_per_seed.csv) · [Kiểm tra cột](bar_visibility_audit.csv) · [Mean/std/CI95](aggregate.csv) · [So sánh cặp](paired_comparisons.csv) · [Kiểm chứng](verification.json) · [Bộ dữ liệu ZIP](du_lieu_10000s.zip)

## Phương pháp và quy tắc chốt dữ liệu

Hoàn tất 480/480 lượt hợp lệ, 16 cấu hình × 30 seed (51001–51030), 0 lượt lỗi/còn thiếu. Mỗi seed tạo topology độc lập; cùng seed giữa các treatment giữ topology và các stream ngoại sinh. Không loại seed vì kết quả bất lợi. Đơn vị thống kê là lượt/seed, không phải node, gói hoặc cửa sổ. Profile chính thức: WSN_SECURITY_FIXED_HORIZON_10000S_V1; job scope EVALUATION_FIXED_HORIZON_10000S, config_profile CUSTOM, không dùng nhãn PILOT/TEST_ONLY cho evaluation.

Mỗi lượt quan sát t ∈ [0,10.000] giây, tối đa 1000 round, sinh gói mỗi 10 giây từ t=10 đến t=10.000. Xử lý toàn bộ sự kiện tại t=10.000 theo thứ tự hàng đợi SimPy, chốt detector tại thời điểm này, không chạy xả sau mốc. Gói đã sinh nhưng chưa có sự kiện kết thúc giữ pending_in_flight. PDR dùng toàn bộ gói sinh trong khoảng đo, bao gồm gói đang truyền ở mẫu số. Quy tắc cutoff được kiểm tra bằng ca một sensor: 1.000 gói sinh, 999 gói đến và 1 gói đang truyền.

Giữ 450 sensor, 7 sink, vùng 3.000 × 3.000 m, E0=5 J, Eth=1 J, R=300 m, wire=payload=128 byte, chu kỳ 10 s, p_channel=0,01. Detector giữ beta=0,8; cửa sổ 40 s; timeout 0,02 s; minObs=2; tau=0,95; K=1; trust ban đầu=1; cách ly 60 s. Bán kính kế thừa quyết định pilot trước đó. Không sửa lõi, lock hoặc tham số để làm đẹp kết quả.

Các mức attacker 2%, 5%, 10% là tỷ lệ yêu cầu; làm tròn nửa lên trên 450 sensor thành 9, 23, 45 attacker. Mức 5% thực tế là 23/450 ≈ 5,111%. Tập attacker không gồm sink; số lượng và tỷ lệ thực nằm trong manifest/CSV. Giữ cùng tập ID giữa các thuật toán trong cùng treatment; vị trí khác nhau thay tập ID theo quy tắc nhưng giữ topology và số lượng.

Throughput = wire bit nhận duy nhất tại sink / 10.000 s; goodput = payload bit nhận / 10.000 s. Vì wire=payload, hai giá trị bằng nhau trong mô hình này. Năng lượng/bit = năng lượng sensor tiêu hao từ t=0 đến t=10.000 / payload bit nhận thành công. Delay và hop lấy đúng gói hoàn tất trước hoặc tại cutoff, không lấy giá trị cuối của lượt 100.000 s rồi đổi nhãn. Các trạng thái TP/FP/TN/FN, coverage, cảnh báo và cách ly đều chốt tại t=10.000.

Mean và độ lệch chuẩn mẫu (ddof=1) tính trên seed có chỉ số xác định; CI95 = mean ± t(0,975,n−1)×std/√n. CSV giữ n_expected/n_used/n_missing và NA cho mẫu số 0. So sánh cặp trên matched seeds, xác minh pairing hash/topology/attacker IDs, dùng paired t và Wilcoxon-Pratt, hiệu chỉnh Holm trên toàn họ chỉ số/cặp đã khai báo. CI95 của chênh lệch cặp giữ trong CSV; không thay CI bằng error bar trong ảnh. CI tỷ lệ là khoảng t cho mean theo seed và có thể vượt [0,1]; không cắt để che biến thiên.

Độ trễ phát hiện/cách ly thực theo attacker giữ NA nếu chưa thấy sự kiện. Chỉ số capped delay lấy min(delay,10.000) và dùng 10.000 cho attacker bị kiểm duyệt, rồi trung bình trong mỗi seed và qua 30 seed. Giá trị giới hạn không phải thời gian phát hiện thực của attacker chưa bị phát hiện. TPR/FPR tính trên toàn bộ sensor, coverage mô tả tập có đủ quan sát, không loại attacker không quan sát để tăng TPR.

FND là sensor đầu tiên chết; HND là ít nhất 225/450 sensor chết; LND là toàn bộ 450 sensor chết. Mốc không xảy ra giữ time_s/payload=NA và censored=true, không gán 0 hoặc coi 10.000 s là thời điểm chết thật. Thời gian giới hạn là min(T,10.000 s). Payload trước mốc chỉ trung bình trong các lượt đạt mốc, không dùng để xếp hạng nhóm có mức kiểm duyệt khác nhau. Mốc mất chức năng theo physical/routing reachability là chỉ số khác với HND/LND.

Hai ô payload trước HND/LND cũ không đủ quan sát để so sánh. Bộ hình chính đã thay bằng payload đến sink, sensor sống và năng lượng còn lại tại 10.000 s. Bảng dưới giữ n_observed/n_runs cho mọi mốc và mọi cấu hình. Cấu hình/phương pháp nằm trong báo cáo và metadata; ảnh chỉ giữ tiêu đề, trục/đơn vị, legend và số phía trên cột.

Phạm vi 10.000 s được chọn theo yêu cầu người dùng sau khi đã xem checkpoint dài hạn, không phải đăng ký trước khi xem dữ liệu dài hạn. Toàn bộ 480 lượt này được chạy mới trong profile ngắn; không trộn mean hay delay/hop từ kết quả dài hạn. Báo cáo và dữ liệu 100.000 s cũ giữ riêng, không ghi đè.

Số quyết định tìm lại tuyến có nguyên nhân chính security chỉ đếm việc sửa một tuyến đã gán. Tuyến được chọn mới ngay khi sinh gói có thể tránh node cách ly mà không tạo sự kiện reroute. Vì vậy số đếm security bằng 0 không tự chứng minh S-EMHR không tránh relay hoặc không có chi phí bảo vệ; trạng thái bật/tắt tránh relay và các chi phí chưa mô phỏng được công bố riêng.

Tỷ lệ 100% ở ô quan sát FND nghĩa là 30/30 lượt đã có ít nhất một sensor chết, không phải toàn bộ 450 sensor đã chết.

Chuỗi thời gian được ghi mỗi 100 s để giảm chi phí lưu và tổng hợp; chu kỳ sinh gói vẫn là 10 s và mốc chết vẫn được ghi theo đúng sự kiện. Các chỗ còn ghi 1.000 s trong mẫu yêu cầu được thống nhất thành 10.000 s theo các mục cấu hình/nghiệm thu mới. Kế hoạch gốc có giới hạn 100.000 s; báo cáo hiện tại là phạm vi 10.000 s điều chỉnh theo yêu cầu, không tuyên bố thay thế đầy đủ nghiên cứu dài hạn. Bộ 1.000 s và 100.000 s cũ đều được bảo toàn.

Đã kiểm tra mọi cột từ CSV đến ảnh. Mean bằng 0 giữ chiều cao 0, có vòng tròn tại đường gốc và nhãn số để phân biệt với thiếu dữ liệu. Mean không xác định trong các hình chính làm xuất báo cáo dừng để kiểm tra; không điền số giả. Các mốc HND/LND thiếu quan sát chỉ ở bảng kiểm duyệt, không tạo ô hình trống. Bảng kiểm tra hiển thị và bar_visibility_audit.csv ghi trạng thái từng cột. Nhóm không bật detector không được vẽ trong ô chỉ dành cho detector; đây là chọn đúng phạm vi chỉ số, không phải bỏ dữ liệu bất lợi.

Đồ thị độ nhạy dùng trục tung theo khoảng số liệu để nhìn rõ các mức đã đo, với nhãn mean tại từng điểm. Trục cột vẫn bắt đầu từ 0. Độ dốc nhìn thấy không tự chứng minh ý nghĩa thống kê; phải đọc cùng độ lớn chênh lệch, CI95 và so sánh cặp.

Protocol hiệu lực ghi rõ quy tắc cutoff 10.000 s. Bản đăng ký gốc được giữ nguyên hash; một chuỗi mô tả còn sót 1.000 trong mẫu được đính chính riêng ở protocol_effective.json. Không đổi cấu hình chạy, kết quả, run ID hoặc completion hash vì chỉnh mô tả này.

relay_security_per_seed.csv lưu bộ đếm nhận/chuyển tiếp/timeout/pending, trust và cờ nghi ngờ/cách ly của từng relay tại cutoff. Tỷ số F/N trong CSV này được ghi rõ là tỷ số tích lũy để đối chiếu, không phải forwarding ratio từng cửa sổ đã dùng cập nhật EWMA. Batch dùng full_trace=false để tiết kiệm tài nguyên; không tuyên bố đã lưu lại đầy đủ log từng gói hoặc lịch sử từng cửa sổ. Các bài kiểm tra module và demo chi tiết được giữ riêng trong dự án.

## Nhận xét ưu điểm và hạn chế

MHR không tấn công đạt PDR 40,983%, năng lượng/bit 11,439 µJ/bit và 261,07 sensor còn sống. EMHR tương ứng 34,381%, 9,035 µJ/bit và 352,03 sensor. MHR dùng tuyến hop tối thiểu trên graph vật lý; EMHR xét ngưỡng năng lượng relay. Số liệu cho thấy đánh đổi giữa duy trì relay, dữ liệu nhận và chi phí radio; không suy rộng ưu thế của MHR/SF-2 ra các mức độ nhạy chưa chạy.

Ở nhóm không tấn công, EMHR thay đổi goodput 9,16% và năng lượng/bit -21,02% so với MHR. Đọc PDR cùng lượng gói sinh: sensor chết làm giảm số gói sinh của MHR, nên PDR cao hơn riêng lẻ chưa đồng nghĩa nhận nhiều payload hơn. Khả năng giữ sensor sống và năng lượng/bit là ưu điểm quan sát được của EMHR trong cửa sổ này; ngưỡng relay cũng có thể làm một số nguồn còn pin mất tuyến hợp lệ.

Selective Forwarding làm PDR của MHR-SF còn 40,625% và EMHR-SF còn 34,182%. S-EMHR đạt 34,144%, thay đổi goodput 0,14% so với EMHR-SF và 9,49% so với MHR-SF. Đây là các giá trị trung bình tại cấu hình trung tâm; bảng cặp giữ CI95 và p đã hiệu chỉnh để đánh giá độ chắc chắn.

S-EMHR có năng lượng/bit 9,361 µJ/bit, trễ 10,207 ms và 2,492 hop; EMHR-SF tương ứng 9,328 µJ/bit, 9,999 ms và 2,441 hop. Tránh relay bị cách ly có thể thay đổi độ dài tuyến và số nguồn còn đường đi. Delay/hop chỉ mô tả gói đã đến sink, nên phải đọc cùng PDR, mất gói và reachability; tiết kiệm năng lượng nhờ bỏ gói sớm không tự chứng minh hiệu quả giao dữ liệu.

SF-2 quan sát thụ động và không tránh relay, nên các chỉ số giao dữ liệu/radio trùng EMHR-SF khi dùng cùng seed. Sự trùng nhau này phù hợp mô hình chưa thu chi phí giám sát; không có nghĩa detector ngoài thực tế không tiêu tốn tài nguyên.

SF-2 chỉ phát hiện đạt PDR 34,182%, S-EMHR đạt 34,144%. TPR của hai phương án là 83,913% và 85,217%; FPR 7,572% và 11,179%; precision 38,683% và 30,072%; coverage 85,015% và 86,489%. Giữ cả báo nhầm, bỏ sót và attacker chưa đủ cơ hội chuyển tiếp. Bộ detector đã khóa từ benign calibration hữu hạn; không coi đó là bảo đảm FPR ở mọi horizon và không tinh chỉnh lại bằng 30 seed evaluation.

Các bảng độ nhạy giữ tất cả sáu treatment tấn công đã đo. Thiết kế thay đổi một yếu tố mỗi lần chưa ước lượng tương tác giữa tỷ lệ attacker, P_drop và vị trí; không nối kết quả để khẳng định toàn bộ tích Descartes. Near-sink chọn theo khoảng cách Euclid đến sink gần nhất, phá hòa bằng ID sensor, độc lập với kết quả định tuyến.

Tại 10.000 s, số sensor sống còn tuyến hợp lệ trung bình là 42,27 với MHR, 46,73 với EMHR, 47,20 với EMHR-SF và 46,77 với S-EMHR. Bảng trung tâm đặt số sensor còn sống cạnh số nối vật lý và số có tuyến hợp lệ để phân biệt còn pin với duy trì khả năng truyền đến sink.

Trong toàn bộ 480 lượt mới, HND được quan sát ở 5/480 lượt, LND ở 0/480 lượt. Các mốc còn lại giữ NA/censored trong bảng. Bảng FND và hai đường số sensor sống/năng lượng cho phép đánh giá suy giảm ngắn hạn; không biến 10.000 s thành tuổi thọ thực của các seed chưa đạt mốc.

Ở SF-2, detector tạo trung bình 382,10 đề xuất cách ly nhưng chế độ tránh relay tắt. S-EMHR có 561,63 đề xuất và bật ràng buộc tránh relay. Số quyết định tìm lại tuyến có nguyên nhân chính là an ninh lấy trực tiếp từ log: 0,00 với SF-2 và 0,00 với S-EMHR. Số đề xuất có thể lặp lại trên cùng node, gồm cả báo nhầm; không phải số attacker duy nhất hoặc số lần đổi tuyến thực sự. Nhóm không bật detector không xuất hiện ở ô đề xuất cách ly, nhưng số đếm 0 vẫn giữ trong CSV.

PDR toàn kỳ có thể chịu ảnh hưởng mạnh của relay dưới ngưỡng và nguồn còn sống nhưng mất tuyến. Vì vậy tăng xác suất bỏ gói không bắt buộc làm mọi chỉ số trung bình toàn kỳ biến thiên đơn điệu. Đọc các đường độ nhạy cùng tỷ lệ unreachable, selective_forwarding, số sensor còn tuyến và đường năng lượng; không đổi horizon hoặc loại seed chỉ để S-EMHR có kết quả tốt hơn.

Ở cấu hình trung tâm, phần gói sinh ra bị Selective Forwarding là 2,0105% với EMHR-SF và 1,1268% với S-EMHR. Phần gói không có tuyến tương ứng 62,8564% và 63,7806%. Giảm mất gói do tấn công đi kèm thay đổi mất gói do không có tuyến; TPR cao hơn không tự bảo đảm PDR/goodput hoặc tuổi thọ cao hơn. Bảng trạng thái gói giữ cả hai nguyên nhân và các chi phí radio đã đo.

## Giới hạn diễn giải

Quan sát 10.000 giây phản ánh hiệu năng ngắn hạn. Khi HND/LND chưa xảy ra, dữ liệu này không xác định hoặc chứng minh đầy đủ tuổi thọ dài hạn.

Mô hình radio hiện tính năng lượng TX/RX, chưa có tiêu hao idle, MAC, ACK, hàng đợi, retransmission và chi phí giám sát/điều khiển. Các chi phí này giữ NA; không thể suy ra tổng chi phí triển khai thực hoặc mặc định S-EMHR rẻ hơn mọi mặt.

Sensor còn sống nhưng mất kết nối vẫn có thể tồn tại lâu vì chưa có idle. Do đó còn pin, còn sống, còn đường đi và khả năng giao dữ liệu là các đại lượng khác nhau.

Detector dùng quan sát lý tưởng từ SimPy, chưa mô phỏng overhearing/ACK thực. Cần kiểm chứng thêm với chi phí giao thức và horizon dài hơn để kết luận về triển khai.

## Hiệu năng cấu hình trung tâm

| Kịch bản | PDR (%) | Throughput (kbit/s) | Goodput (kbit/s) | µJ/bit | Trễ (ms) | Hop | Payload (Mbit) | Sensor sống | Năng lượng còn (J) | Sống và nối vật lý tới sink | Sống và có tuyến hợp lệ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MHR | 40,983 | 12,567 | 12,567 | 11,439 | 11,232 | 2,742 | 125,675 | 261,07 | 828,77 | 42,27 | 42,27 |
| EMHR | 34,381 | 13,719 | 13,719 | 9,035 | 10,349 | 2,527 | 137,192 | 352,03 | 1 021,73 | 283,73 | 46,73 |
| MHR-SF | 40,625 | 12,427 | 12,427 | 11,783 | 10,725 | 2,619 | 124,275 | 257,20 | 803,69 | 42,87 | 42,87 |
| EMHR-SF | 34,182 | 13,589 | 13,589 | 9,328 | 9,999 | 2,441 | 135,886 | 348,83 | 994,24 | 289,17 | 47,20 |
| SF-2 | 34,182 | 13,589 | 13,589 | 9,328 | 9,999 | 2,441 | 135,886 | 348,83 | 994,24 | 289,17 | 47,20 |
| S-EMHR | 34,144 | 13,607 | 13,607 | 9,361 | 10,207 | 2,492 | 136,071 | 350,20 | 990,20 | 304,17 | 46,77 |

## Bảo mật cấu hình trung tâm

| Kịch bản | TP | FP | TN | FN | tpr | fpr | precision | f1 | coverage | detection_capped_delay_s | isolation_capped_delay_s | detector_isolation_events | unique_isolated_by_cutoff | Tránh relay |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SF-2 | 19,300 | 32,333 | 394,667 | 3,700 | 83,913 | 7,572 | 38,683 | 52,562 | 85,015 | 2 220,116 | 2 220,116 | 382,100 | 51,633 | Tắt |
| S-EMHR | 19,600 | 47,733 | 379,267 | 3,400 | 85,217 | 11,179 | 30,072 | 44,124 | 86,489 | 2 054,957 | 2 054,957 | 561,633 | 67,333 | Bật |

## So sánh cặp tại cấu hình trung tâm

| Cặp (A − B) | Chỉ số | n cặp | Chênh lệch | CI95 thấp | CI95 cao | Thay đổi (%) | p t/Holm | p Wilcoxon/Holm |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| S-EMHR − SF-2 | PDR (%) | 30 | -0,0378 | -0,1793 | 0,1036 | -0,11 | 1,00000 | 1,00000 |
| S-EMHR − SF-2 | Thông lượng (kbit/s) | 30 | 0,0185 | -0,0194 | 0,0564 | 0,14 | 1,00000 | 1,00000 |
| S-EMHR − SF-2 | Goodput (kbit/s) | 30 | 0,0185 | -0,0194 | 0,0564 | 0,14 | 1,00000 | 1,00000 |
| S-EMHR − SF-2 | Năng lượng (µJ/bit payload) | 30 | 0,0324 | -0,0402 | 0,1051 | 0,35 | 1,00000 | 1,00000 |
| S-EMHR − SF-2 | Độ trễ đầu cuối (ms) | 30 | 0,2075 | 0,1531 | 0,2620 | 2,08 | <0,00001 | <0,00001 |
| S-EMHR − SF-2 | Số hop trung bình | 30 | 0,0507 | 0,0374 | 0,0640 | 2,08 | <0,00001 | <0,00001 |
| S-EMHR − EMHR-SF | PDR (%) | 30 | -0,0378 | -0,1793 | 0,1036 | -0,11 | 1,00000 | 1,00000 |
| S-EMHR − EMHR-SF | Thông lượng (kbit/s) | 30 | 0,0185 | -0,0194 | 0,0564 | 0,14 | 1,00000 | 1,00000 |
| S-EMHR − EMHR-SF | Goodput (kbit/s) | 30 | 0,0185 | -0,0194 | 0,0564 | 0,14 | 1,00000 | 1,00000 |
| S-EMHR − EMHR-SF | Năng lượng (µJ/bit payload) | 30 | 0,0324 | -0,0402 | 0,1051 | 0,35 | 1,00000 | 1,00000 |
| S-EMHR − EMHR-SF | Độ trễ đầu cuối (ms) | 30 | 0,2075 | 0,1531 | 0,2620 | 2,08 | <0,00001 | <0,00001 |
| S-EMHR − EMHR-SF | Số hop trung bình | 30 | 0,0507 | 0,0374 | 0,0640 | 2,08 | <0,00001 | <0,00001 |
| S-EMHR − MHR-SF | PDR (%) | 30 | -6,4810 | -7,4985 | -5,4634 | -15,95 | <0,00001 | <0,00001 |
| S-EMHR − MHR-SF | Thông lượng (kbit/s) | 30 | 1,1796 | 1,0140 | 1,3452 | 9,49 | <0,00001 | <0,00001 |
| S-EMHR − MHR-SF | Goodput (kbit/s) | 30 | 1,1796 | 1,0140 | 1,3452 | 9,49 | <0,00001 | <0,00001 |
| S-EMHR − MHR-SF | Năng lượng (µJ/bit payload) | 30 | -2,4225 | -2,6335 | -2,2115 | -20,56 | <0,00001 | <0,00001 |
| S-EMHR − MHR-SF | Độ trễ đầu cuối (ms) | 30 | -0,5185 | -0,6440 | -0,3930 | -4,83 | <0,00001 | 0,00006 |
| S-EMHR − MHR-SF | Số hop trung bình | 30 | -0,1266 | -0,1572 | -0,0959 | -4,83 | <0,00001 | 0,00006 |

## Độ nhạy của PDR

| Attacker (%) | P_drop | Vị trí | PDR EMHR-SF (%) | PDR S-EMHR (%) | Chênh lệch (điểm %) |
| --- | --- | --- | --- | --- | --- |
| 5 | 0,50 | Ngẫu nhiên | 34,182 | 34,144 | -0,038 |
| 2 | 0,50 | Ngẫu nhiên | 34,260 | 34,299 | 0,039 |
| 10 | 0,50 | Ngẫu nhiên | 33,868 | 33,764 | -0,104 |
| 5 | 0,25 | Ngẫu nhiên | 34,258 | 34,200 | -0,057 |
| 5 | 0,75 | Ngẫu nhiên | 34,111 | 34,049 | -0,062 |
| 5 | 0,50 | Gần sink | 30,847 | 30,140 | -0,708 |

## Kiểm tra hiển thị cột

| Hình | Số cột có số đo | Cột dương | Số 0 có điểm đánh dấu | Cột thiếu dữ liệu |
| --- | --- | --- | --- | --- |
| 01_hieu_nang_trung_tam.png | 36 | 36 | 0 | 0 |
| 02_trang_thai_10000s.png | 18 | 18 | 0 | 0 |
| 03_phat_hien_bao_mat.png | 12 | 12 | 0 | 0 |
| 06_vi_tri_attacker.png | 24 | 24 | 0 | 0 |
| 08_FND_gioi_han.png | 12 | 12 | 0 | 0 |
| 09_trang_thai_goi.png | 6 | 6 | 0 | 0 |
| 10_doi_tuyen_va_cach_ly.png | 14 | 14 | 0 | 0 |

## Ma trận và số seed

| Kịch bản | Attacker (%) | P_drop | Vị trí | Hoàn tất | Lỗi |
| --- | --- | --- | --- | --- | --- |
| MHR | 0 | 0,00 | Ngẫu nhiên | 30/30 | 0 |
| EMHR | 0 | 0,00 | Ngẫu nhiên | 30/30 | 0 |
| MHR-SF | 5 | 0,50 | Ngẫu nhiên | 30/30 | 0 |
| EMHR-SF | 5 | 0,50 | Ngẫu nhiên | 30/30 | 0 |
| SF-2 | 5 | 0,50 | Ngẫu nhiên | 30/30 | 0 |
| S-EMHR | 5 | 0,50 | Ngẫu nhiên | 30/30 | 0 |
| EMHR-SF | 2 | 0,50 | Ngẫu nhiên | 30/30 | 0 |
| S-EMHR | 2 | 0,50 | Ngẫu nhiên | 30/30 | 0 |
| EMHR-SF | 10 | 0,50 | Ngẫu nhiên | 30/30 | 0 |
| S-EMHR | 10 | 0,50 | Ngẫu nhiên | 30/30 | 0 |
| EMHR-SF | 5 | 0,25 | Ngẫu nhiên | 30/30 | 0 |
| S-EMHR | 5 | 0,25 | Ngẫu nhiên | 30/30 | 0 |
| EMHR-SF | 5 | 0,75 | Ngẫu nhiên | 30/30 | 0 |
| S-EMHR | 5 | 0,75 | Ngẫu nhiên | 30/30 | 0 |
| EMHR-SF | 5 | 0,50 | Gần sink | 30/30 | 0 |
| S-EMHR | 5 | 0,50 | Gần sink | 30/30 | 0 |

## Mốc chết và mất chức năng: quan sát/kiểm duyệt

| Case ID | Mốc | n_observed/n_runs | Censored | Thời điểm TB khi đạt (s) | Payload TB khi đạt (Mbit) |
| --- | --- | --- | --- | --- | --- |
| MHR_r0_d0_random | FND | 30/30 | 0 | 152,013 | 6,585 |
| MHR_r0_d0_random | HND | 1/30 | 29 | 7 300,000 | 136,837 |
| MHR_r0_d0_random | LND | 0/30 | 30 | NA | NA |
| MHR_r0_d0_random | functional_network_death | 30/30 | 0 | 2 251,356 | 73,255 |
| MHR_r0_d0_random | functional_routing_network_death | 30/30 | 0 | 2 251,356 | 73,255 |
| EMHR_r0_d0_random | FND | 30/30 | 0 | 1 195,333 | 49,688 |
| EMHR_r0_d0_random | HND | 0/30 | 30 | NA | NA |
| EMHR_r0_d0_random | LND | 0/30 | 30 | NA | NA |
| EMHR_r0_d0_random | functional_network_death | 6/30 | 24 | 8 026,667 | 116,868 |
| EMHR_r0_d0_random | functional_routing_network_death | 30/30 | 0 | 1 875,350 | 70,668 |
| MHR_SF_r0.05_d0.5_random | FND | 30/30 | 0 | 157,345 | 6,532 |
| MHR_SF_r0.05_d0.5_random | HND | 4/30 | 26 | 7 237,502 | 128,110 |
| MHR_SF_r0.05_d0.5_random | LND | 0/30 | 30 | NA | NA |
| MHR_SF_r0.05_d0.5_random | functional_network_death | 30/30 | 0 | 2 449,347 | 73,300 |
| MHR_SF_r0.05_d0.5_random | functional_routing_network_death | 30/30 | 0 | 2 449,347 | 73,300 |
| EMHR_SF_r0.05_d0.5_random | FND | 30/30 | 0 | 1 211,667 | 47,672 |
| EMHR_SF_r0.05_d0.5_random | HND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.05_d0.5_random | LND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.05_d0.5_random | functional_network_death | 5/30 | 25 | 7 750,000 | 112,332 |
| EMHR_SF_r0.05_d0.5_random | functional_routing_network_death | 30/30 | 0 | 2 066,351 | 71,807 |
| SF2_r0.05_d0.5_random | FND | 30/30 | 0 | 1 211,667 | 47,672 |
| SF2_r0.05_d0.5_random | HND | 0/30 | 30 | NA | NA |
| SF2_r0.05_d0.5_random | LND | 0/30 | 30 | NA | NA |
| SF2_r0.05_d0.5_random | functional_network_death | 5/30 | 25 | 7 750,000 | 112,332 |
| SF2_r0.05_d0.5_random | functional_routing_network_death | 30/30 | 0 | 2 066,351 | 71,807 |
| SF3_r0.05_d0.5_random | FND | 30/30 | 0 | 1 203,667 | 48,852 |
| SF3_r0.05_d0.5_random | HND | 0/30 | 30 | NA | NA |
| SF3_r0.05_d0.5_random | LND | 0/30 | 30 | NA | NA |
| SF3_r0.05_d0.5_random | functional_network_death | 4/30 | 26 | 7 952,500 | 109,650 |
| SF3_r0.05_d0.5_random | functional_routing_network_death | 30/30 | 0 | 1 897,019 | 69,286 |
| EMHR_SF_r0.02_d0.5_random | FND | 30/30 | 0 | 1 199,333 | 48,831 |
| EMHR_SF_r0.02_d0.5_random | HND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.02_d0.5_random | LND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.02_d0.5_random | functional_network_death | 5/30 | 25 | 7 854,000 | 114,182 |
| EMHR_SF_r0.02_d0.5_random | functional_routing_network_death | 30/30 | 0 | 1 948,351 | 71,044 |
| SF3_r0.02_d0.5_random | FND | 30/30 | 0 | 1 194,667 | 49,206 |
| SF3_r0.02_d0.5_random | HND | 0/30 | 30 | NA | NA |
| SF3_r0.02_d0.5_random | LND | 0/30 | 30 | NA | NA |
| SF3_r0.02_d0.5_random | functional_network_death | 7/30 | 23 | 8 221,429 | 116,924 |
| SF3_r0.02_d0.5_random | functional_routing_network_death | 30/30 | 0 | 1 889,016 | 70,264 |
| EMHR_SF_r0.1_d0.5_random | FND | 30/30 | 0 | 1 234,667 | 45,925 |
| EMHR_SF_r0.1_d0.5_random | HND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.1_d0.5_random | LND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.1_d0.5_random | functional_network_death | 6/30 | 24 | 8 156,667 | 114,536 |
| EMHR_SF_r0.1_d0.5_random | functional_routing_network_death | 30/30 | 0 | 2 235,349 | 72,679 |
| SF3_r0.1_d0.5_random | FND | 30/30 | 0 | 1 216,333 | 48,001 |
| SF3_r0.1_d0.5_random | HND | 0/30 | 30 | NA | NA |
| SF3_r0.1_d0.5_random | LND | 0/30 | 30 | NA | NA |
| SF3_r0.1_d0.5_random | functional_network_death | 4/30 | 26 | 8 577,500 | 119,570 |
| SF3_r0.1_d0.5_random | functional_routing_network_death | 30/30 | 0 | 1 908,680 | 67,854 |
| EMHR_SF_r0.05_d0.25_random | FND | 30/30 | 0 | 1 202,000 | 48,807 |
| EMHR_SF_r0.05_d0.25_random | HND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.05_d0.25_random | LND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.05_d0.25_random | functional_network_death | 5/30 | 25 | 7 704,000 | 112,763 |
| EMHR_SF_r0.05_d0.25_random | functional_routing_network_death | 30/30 | 0 | 1 944,687 | 70,937 |
| SF3_r0.05_d0.25_random | FND | 30/30 | 0 | 1 205,000 | 49,437 |
| SF3_r0.05_d0.25_random | HND | 0/30 | 30 | NA | NA |
| SF3_r0.05_d0.25_random | LND | 0/30 | 30 | NA | NA |
| SF3_r0.05_d0.25_random | functional_network_death | 5/30 | 25 | 8 114,000 | 113,467 |
| SF3_r0.05_d0.25_random | functional_routing_network_death | 30/30 | 0 | 1 874,681 | 69,578 |
| EMHR_SF_r0.05_d0.75_random | FND | 30/30 | 0 | 1 217,000 | 45,913 |
| EMHR_SF_r0.05_d0.75_random | HND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.05_d0.75_random | LND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.05_d0.75_random | functional_network_death | 6/30 | 24 | 8 306,667 | 118,588 |
| EMHR_SF_r0.05_d0.75_random | functional_routing_network_death | 30/30 | 0 | 2 269,347 | 73,129 |
| SF3_r0.05_d0.75_random | FND | 30/30 | 0 | 1 205,000 | 48,279 |
| SF3_r0.05_d0.75_random | HND | 0/30 | 30 | NA | NA |
| SF3_r0.05_d0.75_random | LND | 0/30 | 30 | NA | NA |
| SF3_r0.05_d0.75_random | functional_network_death | 2/30 | 28 | 7 175,000 | 127,981 |
| SF3_r0.05_d0.75_random | functional_routing_network_death | 30/30 | 0 | 1 935,014 | 69,191 |
| EMHR_SF_r0.05_d0.5_near_sink | FND | 30/30 | 0 | 1 195,333 | 44,315 |
| EMHR_SF_r0.05_d0.5_near_sink | HND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.05_d0.5_near_sink | LND | 0/30 | 30 | NA | NA |
| EMHR_SF_r0.05_d0.5_near_sink | functional_network_death | 7/30 | 23 | 8 054,286 | 107,151 |
| EMHR_SF_r0.05_d0.5_near_sink | functional_routing_network_death | 30/30 | 0 | 1 879,681 | 62,449 |
| SF3_r0.05_d0.5_near_sink | FND | 30/30 | 0 | 1 198,000 | 47,217 |
| SF3_r0.05_d0.5_near_sink | HND | 0/30 | 30 | NA | NA |
| SF3_r0.05_d0.5_near_sink | LND | 0/30 | 30 | NA | NA |
| SF3_r0.05_d0.5_near_sink | functional_network_death | 1/30 | 29 | 7 710,000 | 118,225 |
| SF3_r0.05_d0.5_near_sink | functional_routing_network_death | 30/30 | 0 | 1 651,356 | 60,933 |

## Thống kê đầy đủ: mean/std/CI95 theo seed

| Case ID | Chỉ số | Đơn vị | n hợp lệ | n thiếu/NA | Mean | Std mẫu | CI95 thấp | CI95 cao |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MHR_r0_d0_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 40,98270 | 7,02032 | 38,36127 | 43,60413 |
| MHR_r0_d0_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 12,56749 | 1,70162 | 11,93209 | 13,20288 |
| MHR_r0_d0_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 12,56749 | 1,70162 | 11,93209 | 13,20288 |
| MHR_r0_d0_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 11,43870 | 1,29485 | 10,95520 | 11,92221 |
| MHR_r0_d0_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 11,23170 | 0,87219 | 10,90602 | 11,55738 |
| MHR_r0_d0_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,74211 | 0,21294 | 2,66260 | 2,82163 |
| MHR_r0_d0_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 1 602,36667 | 591,43312 | 1 381,52191 | 1 823,21142 |
| MHR_r0_d0_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 10 585,70000 | 4 345,08826 | 8 963,21738 | 12 208,18262 |
| MHR_r0_d0_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 0 | 30 | NA | NA | NA | NA |
| MHR_r0_d0_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_r0_d0_random | Độ chính xác của cảnh báo | Precision (%) | 0 | 30 | NA | NA | NA | NA |
| MHR_r0_d0_random | Trung bình điều hòa Precision–Recall | F1 (%) | 0 | 30 | NA | NA | NA | NA |
| MHR_r0_d0_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_r0_d0_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 0 | 30 | NA | NA | NA | NA |
| MHR_r0_d0_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| MHR_r0_d0_random | detection_event_coverage | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| MHR_r0_d0_random | isolation_event_coverage | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| MHR_r0_d0_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_r0_d0_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 152,01338 | 45,96563 | 134,84953 | 169,17723 |
| MHR_r0_d0_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 6 584 866,13333 | 2 035 765,99025 | 5 824 698,61957 | 7 345 033,64709 |
| MHR_r0_d0_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 910,00000 | 492,95030 | 9 725,92933 | 10 094,07067 |
| MHR_r0_d0_random | HND_payload_bits | đơn vị gốc trong CSV | 1 | 29 | 136 837 120,00000 | NA | NA | NA |
| MHR_r0_d0_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| MHR_r0_d0_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_r0_d0_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 34,38121 | 5,18960 | 32,44338 | 36,31904 |
| EMHR_r0_d0_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,71921 | 1,85797 | 13,02543 | 14,41299 |
| EMHR_r0_d0_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,71921 | 1,85797 | 13,02543 | 14,41299 |
| EMHR_r0_d0_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,03471 | 0,85514 | 8,71540 | 9,35403 |
| EMHR_r0_d0_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 10,34910 | 0,65712 | 10,10373 | 10,59447 |
| EMHR_r0_d0_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,52664 | 0,16043 | 2,46673 | 2,58654 |
| EMHR_r0_d0_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 366,23333 | 548,68531 | 2 161,35087 | 2 571,11579 |
| EMHR_r0_d0_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 10 772,26667 | 3 759,58938 | 9 368,41292 | 12 176,12041 |
| EMHR_r0_d0_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 0 | 30 | NA | NA | NA | NA |
| EMHR_r0_d0_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_r0_d0_random | Độ chính xác của cảnh báo | Precision (%) | 0 | 30 | NA | NA | NA | NA |
| EMHR_r0_d0_random | Trung bình điều hòa Precision–Recall | F1 (%) | 0 | 30 | NA | NA | NA | NA |
| EMHR_r0_d0_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_r0_d0_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 0 | 30 | NA | NA | NA | NA |
| EMHR_r0_d0_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_r0_d0_random | detection_event_coverage | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_r0_d0_random | isolation_event_coverage | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_r0_d0_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_r0_d0_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 195,33333 | 103,08126 | 1 156,84216 | 1 233,82451 |
| EMHR_r0_d0_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 49 687 790,93333 | 4 826 222,63619 | 47 885 649,78362 | 51 489 932,08305 |
| EMHR_r0_d0_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_r0_d0_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_r0_d0_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_r0_d0_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| MHR_SF_r0.05_d0.5_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 40,62461 | 7,08531 | 37,97892 | 43,27031 |
| MHR_SF_r0.05_d0.5_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 12,42749 | 1,70946 | 11,78917 | 13,06581 |
| MHR_SF_r0.05_d0.5_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 12,42749 | 1,70946 | 11,78917 | 13,06581 |
| MHR_SF_r0.05_d0.5_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 11,78309 | 1,40162 | 11,25971 | 12,30646 |
| MHR_SF_r0.05_d0.5_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 10,72539 | 0,75978 | 10,44169 | 11,00910 |
| MHR_SF_r0.05_d0.5_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,61850 | 0,18549 | 2,54924 | 2,68777 |
| MHR_SF_r0.05_d0.5_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 1 440,13333 | 486,77303 | 1 258,36930 | 1 621,89737 |
| MHR_SF_r0.05_d0.5_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 9 359,60000 | 3 618,72339 | 8 008,34648 | 10 710,85352 |
| MHR_SF_r0.05_d0.5_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | Độ chính xác của cảnh báo | Precision (%) | 0 | 30 | NA | NA | NA | NA |
| MHR_SF_r0.05_d0.5_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| MHR_SF_r0.05_d0.5_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| MHR_SF_r0.05_d0.5_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 157,34535 | 47,11627 | 139,75184 | 174,93885 |
| MHR_SF_r0.05_d0.5_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 6 531 925,33333 | 2 064 316,33970 | 5 761 096,94388 | 7 302 753,72279 |
| MHR_SF_r0.05_d0.5_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 631,66694 | 1 041,12990 | 9 242,90265 | 10 020,43123 |
| MHR_SF_r0.05_d0.5_random | HND_payload_bits | đơn vị gốc trong CSV | 4 | 26 | 128 109 568,00000 | 10 822 119,99102 | 110 889 160,10963 | 145 329 975,89037 |
| MHR_SF_r0.05_d0.5_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| MHR_SF_r0.05_d0.5_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.5_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 34,18151 | 5,26975 | 32,21375 | 36,14926 |
| EMHR_SF_r0.05_d0.5_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,58857 | 1,86697 | 12,89143 | 14,28571 |
| EMHR_SF_r0.05_d0.5_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,58857 | 1,86697 | 12,89143 | 14,28571 |
| EMHR_SF_r0.05_d0.5_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,32816 | 0,89820 | 8,99277 | 9,66356 |
| EMHR_SF_r0.05_d0.5_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 9,99935 | 0,61301 | 9,77045 | 10,22825 |
| EMHR_SF_r0.05_d0.5_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,44125 | 0,14966 | 2,38536 | 2,49713 |
| EMHR_SF_r0.05_d0.5_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 178,80000 | 446,74882 | 2 011,98125 | 2 345,61875 |
| EMHR_SF_r0.05_d0.5_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 10 316,26667 | 3 550,07703 | 8 990,64612 | 11 641,88721 |
| EMHR_SF_r0.05_d0.5_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | Độ chính xác của cảnh báo | Precision (%) | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.5_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.5_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.5_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 211,66667 | 101,54270 | 1 173,75000 | 1 249,58333 |
| EMHR_SF_r0.05_d0.5_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 47 672 285,86667 | 4 842 033,97905 | 45 864 240,66450 | 49 480 331,06883 |
| EMHR_SF_r0.05_d0.5_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.5_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.5_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.5_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF2_r0.05_d0.5_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 34,18151 | 5,26975 | 32,21375 | 36,14926 |
| SF2_r0.05_d0.5_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,58857 | 1,86697 | 12,89143 | 14,28571 |
| SF2_r0.05_d0.5_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,58857 | 1,86697 | 12,89143 | 14,28571 |
| SF2_r0.05_d0.5_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,32816 | 0,89820 | 8,99277 | 9,66356 |
| SF2_r0.05_d0.5_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 9,99935 | 0,61301 | 9,77045 | 10,22825 |
| SF2_r0.05_d0.5_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,44125 | 0,14966 | 2,38536 | 2,49713 |
| SF2_r0.05_d0.5_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 178,80000 | 446,74882 | 2 011,98125 | 2 345,61875 |
| SF2_r0.05_d0.5_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 10 316,26667 | 3 550,07703 | 8 990,64612 | 11 641,88721 |
| SF2_r0.05_d0.5_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 83,91304 | 9,28652 | 80,44540 | 87,38069 |
| SF2_r0.05_d0.5_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 7,57221 | 2,46877 | 6,65035 | 8,49406 |
| SF2_r0.05_d0.5_random | Độ chính xác của cảnh báo | Precision (%) | 30 | 0 | 38,68288 | 7,66113 | 35,82217 | 41,54359 |
| SF2_r0.05_d0.5_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 52,56200 | 8,21542 | 49,49432 | 55,62969 |
| SF2_r0.05_d0.5_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 85,01481 | 3,04957 | 83,87609 | 86,15354 |
| SF2_r0.05_d0.5_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 2 220,11594 | 858,35736 | 1 899,60004 | 2 540,63185 |
| SF2_r0.05_d0.5_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 2 220,11594 | 858,35736 | 1 899,60004 | 2 540,63185 |
| SF2_r0.05_d0.5_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,83913 | 0,09287 | 0,80445 | 0,87381 |
| SF2_r0.05_d0.5_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,83913 | 0,09287 | 0,80445 | 0,87381 |
| SF2_r0.05_d0.5_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 382,10000 | 86,06748 | 349,96188 | 414,23812 |
| SF2_r0.05_d0.5_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 211,66667 | 101,54270 | 1 173,75000 | 1 249,58333 |
| SF2_r0.05_d0.5_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 47 672 285,86667 | 4 842 033,97905 | 45 864 240,66450 | 49 480 331,06883 |
| SF2_r0.05_d0.5_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF2_r0.05_d0.5_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF2_r0.05_d0.5_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF2_r0.05_d0.5_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.05_d0.5_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 34,14366 | 5,27388 | 32,17436 | 36,11296 |
| SF3_r0.05_d0.5_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,60709 | 1,87711 | 12,90617 | 14,30801 |
| SF3_r0.05_d0.5_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,60709 | 1,87711 | 12,90617 | 14,30801 |
| SF3_r0.05_d0.5_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,36057 | 0,97359 | 8,99703 | 9,72411 |
| SF3_r0.05_d0.5_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 10,20689 | 0,65717 | 9,96150 | 10,45228 |
| SF3_r0.05_d0.5_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,49192 | 0,16044 | 2,43201 | 2,55183 |
| SF3_r0.05_d0.5_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 415,50000 | 587,49842 | 2 196,12448 | 2 634,87552 |
| SF3_r0.05_d0.5_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 10 988,26667 | 4 021,18688 | 9 486,73081 | 12 489,80252 |
| SF3_r0.05_d0.5_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 85,21739 | 7,45235 | 82,43464 | 88,00014 |
| SF3_r0.05_d0.5_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 11,17877 | 2,98137 | 10,06550 | 12,29203 |
| SF3_r0.05_d0.5_random | Độ chính xác của cảnh báo | Precision (%) | 30 | 0 | 30,07247 | 5,79740 | 27,90769 | 32,23726 |
| SF3_r0.05_d0.5_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 44,12390 | 6,42130 | 41,72614 | 46,52165 |
| SF3_r0.05_d0.5_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 86,48889 | 2,61860 | 85,51109 | 87,46669 |
| SF3_r0.05_d0.5_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 2 054,95652 | 736,09892 | 1 780,09267 | 2 329,82038 |
| SF3_r0.05_d0.5_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 2 054,95652 | 736,09892 | 1 780,09267 | 2 329,82038 |
| SF3_r0.05_d0.5_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,85217 | 0,07452 | 0,82435 | 0,88000 |
| SF3_r0.05_d0.5_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,85217 | 0,07452 | 0,82435 | 0,88000 |
| SF3_r0.05_d0.5_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 561,63333 | 117,27494 | 517,84215 | 605,42452 |
| SF3_r0.05_d0.5_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 203,66667 | 98,62794 | 1 166,83839 | 1 240,49495 |
| SF3_r0.05_d0.5_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 48 852 172,80000 | 5 075 300,77014 | 46 957 024,34654 | 50 747 321,25346 |
| SF3_r0.05_d0.5_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.05_d0.5_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.05_d0.5_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.05_d0.5_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.02_d0.5_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 34,25963 | 5,23443 | 32,30506 | 36,21420 |
| EMHR_SF_r0.02_d0.5_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,65614 | 1,86050 | 12,96142 | 14,35086 |
| EMHR_SF_r0.02_d0.5_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,65614 | 1,86050 | 12,96142 | 14,35086 |
| EMHR_SF_r0.02_d0.5_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,14129 | 0,86033 | 8,82004 | 9,46255 |
| EMHR_SF_r0.02_d0.5_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 10,19647 | 0,64189 | 9,95679 | 10,43616 |
| EMHR_SF_r0.02_d0.5_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,48937 | 0,15671 | 2,43086 | 2,54789 |
| EMHR_SF_r0.02_d0.5_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 284,20000 | 526,24679 | 2 087,69622 | 2 480,70378 |
| EMHR_SF_r0.02_d0.5_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 10 490,73333 | 3 539,10319 | 9 169,21048 | 11 812,25618 |
| EMHR_SF_r0.02_d0.5_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | Độ chính xác của cảnh báo | Precision (%) | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.02_d0.5_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.02_d0.5_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.02_d0.5_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 199,33333 | 102,45044 | 1 161,07771 | 1 237,58896 |
| EMHR_SF_r0.02_d0.5_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 48 831 283,20000 | 4 887 032,34066 | 47 006 435,33346 | 50 656 131,06654 |
| EMHR_SF_r0.02_d0.5_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.02_d0.5_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.02_d0.5_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.02_d0.5_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.02_d0.5_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 34,29858 | 5,28729 | 32,32427 | 36,27289 |
| SF3_r0.02_d0.5_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,68153 | 1,88334 | 12,97828 | 14,38478 |
| SF3_r0.02_d0.5_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,68153 | 1,88334 | 12,97828 | 14,38478 |
| SF3_r0.02_d0.5_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,15047 | 0,90896 | 8,81106 | 9,48988 |
| SF3_r0.02_d0.5_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 10,28909 | 0,65831 | 10,04327 | 10,53491 |
| SF3_r0.02_d0.5_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,51198 | 0,16072 | 2,45197 | 2,57200 |
| SF3_r0.02_d0.5_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 342,10000 | 580,77821 | 2 125,23385 | 2 558,96615 |
| SF3_r0.02_d0.5_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 10 815,63333 | 3 974,38540 | 9 331,57343 | 12 299,69323 |
| SF3_r0.02_d0.5_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 86,29630 | 10,39179 | 82,41594 | 90,17665 |
| SF3_r0.02_d0.5_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 9,55404 | 3,30310 | 8,32064 | 10,78744 |
| SF3_r0.02_d0.5_random | Độ chính xác của cảnh báo | Precision (%) | 30 | 0 | 16,71863 | 4,57559 | 15,01007 | 18,42718 |
| SF3_r0.02_d0.5_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 27,70566 | 6,40152 | 25,31529 | 30,09603 |
| SF3_r0.02_d0.5_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 85,79259 | 2,85595 | 84,72616 | 86,85902 |
| SF3_r0.02_d0.5_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 2 012,74074 | 934,05536 | 1 663,95874 | 2 361,52274 |
| SF3_r0.02_d0.5_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 2 012,74074 | 934,05536 | 1 663,95874 | 2 361,52274 |
| SF3_r0.02_d0.5_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,86296 | 0,10392 | 0,82416 | 0,90177 |
| SF3_r0.02_d0.5_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,86296 | 0,10392 | 0,82416 | 0,90177 |
| SF3_r0.02_d0.5_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 236,20000 | 71,84821 | 209,37144 | 263,02856 |
| SF3_r0.02_d0.5_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 194,66667 | 99,71454 | 1 157,43265 | 1 231,90069 |
| SF3_r0.02_d0.5_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 49 206 033,06667 | 4 920 392,34844 | 47 368 728,36850 | 51 043 337,76483 |
| SF3_r0.02_d0.5_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.02_d0.5_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.02_d0.5_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.02_d0.5_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.1_d0.5_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 33,86776 | 5,24865 | 31,90788 | 35,82763 |
| EMHR_SF_r0.1_d0.5_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,44486 | 1,84523 | 12,75584 | 14,13388 |
| EMHR_SF_r0.1_d0.5_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,44486 | 1,84523 | 12,75584 | 14,13388 |
| EMHR_SF_r0.1_d0.5_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,62096 | 1,01965 | 9,24022 | 10,00170 |
| EMHR_SF_r0.1_d0.5_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 9,71353 | 0,54500 | 9,51003 | 9,91704 |
| EMHR_SF_r0.1_d0.5_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,37147 | 0,13306 | 2,32178 | 2,42115 |
| EMHR_SF_r0.1_d0.5_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 1 925,30000 | 360,94523 | 1 790,52084 | 2 060,07916 |
| EMHR_SF_r0.1_d0.5_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 9 129,36667 | 3 214,10398 | 7 929,20052 | 10 329,53282 |
| EMHR_SF_r0.1_d0.5_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | Độ chính xác của cảnh báo | Precision (%) | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.1_d0.5_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.1_d0.5_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.1_d0.5_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 234,66667 | 99,78367 | 1 197,40683 | 1 271,92650 |
| EMHR_SF_r0.1_d0.5_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 45 924 625,06667 | 4 375 145,18438 | 44 290 919,00561 | 47 558 331,12772 |
| EMHR_SF_r0.1_d0.5_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.1_d0.5_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.1_d0.5_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.1_d0.5_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.1_d0.5_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 33,76397 | 5,20951 | 31,81871 | 35,70924 |
| SF3_r0.1_d0.5_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,47872 | 1,86428 | 12,78259 | 14,17485 |
| SF3_r0.1_d0.5_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,47872 | 1,86428 | 12,78259 | 14,17485 |
| SF3_r0.1_d0.5_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,67231 | 1,11103 | 9,25745 | 10,08718 |
| SF3_r0.1_d0.5_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 10,09105 | 0,61112 | 9,86286 | 10,31925 |
| SF3_r0.1_d0.5_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,46364 | 0,14920 | 2,40792 | 2,51935 |
| SF3_r0.1_d0.5_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 428,66667 | 553,67489 | 2 221,92106 | 2 635,41227 |
| SF3_r0.1_d0.5_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 11 290,56667 | 3 993,26405 | 9 799,45736 | 12 781,67597 |
| SF3_r0.1_d0.5_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 85,85185 | 4,02137 | 84,35025 | 87,35346 |
| SF3_r0.1_d0.5_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 12,38683 | 4,27179 | 10,79172 | 13,98194 |
| SF3_r0.1_d0.5_random | Độ chính xác của cảnh báo | Precision (%) | 30 | 0 | 45,13306 | 9,13776 | 41,72096 | 48,54516 |
| SF3_r0.1_d0.5_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 58,68330 | 8,06184 | 55,67296 | 61,69364 |
| SF3_r0.1_d0.5_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 87,50370 | 2,54625 | 86,55292 | 88,45449 |
| SF3_r0.1_d0.5_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 1 956,44444 | 433,39717 | 1 794,61128 | 2 118,27761 |
| SF3_r0.1_d0.5_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 1 956,44444 | 433,39717 | 1 794,61128 | 2 118,27761 |
| SF3_r0.1_d0.5_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,85852 | 0,04021 | 0,84350 | 0,87353 |
| SF3_r0.1_d0.5_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,85852 | 0,04021 | 0,84350 | 0,87353 |
| SF3_r0.1_d0.5_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 1 173,23333 | 212,44970 | 1 093,90331 | 1 252,56335 |
| SF3_r0.1_d0.5_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 216,33333 | 95,79012 | 1 180,56471 | 1 252,10195 |
| SF3_r0.1_d0.5_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 48 000 750,93333 | 4 783 222,33796 | 46 214 666,35886 | 49 786 835,50781 |
| SF3_r0.1_d0.5_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.1_d0.5_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.1_d0.5_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.1_d0.5_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.25_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 34,25774 | 5,24948 | 32,29755 | 36,21793 |
| EMHR_SF_r0.05_d0.25_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,65964 | 1,86130 | 12,96462 | 14,35466 |
| EMHR_SF_r0.05_d0.25_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,65964 | 1,86130 | 12,96462 | 14,35466 |
| EMHR_SF_r0.05_d0.25_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,14085 | 0,87631 | 8,81363 | 9,46807 |
| EMHR_SF_r0.05_d0.25_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 10,19434 | 0,63910 | 9,95570 | 10,43298 |
| EMHR_SF_r0.05_d0.25_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,48885 | 0,15603 | 2,43059 | 2,54711 |
| EMHR_SF_r0.05_d0.25_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 209,00000 | 501,02557 | 2 021,91398 | 2 396,08602 |
| EMHR_SF_r0.05_d0.25_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 10 221,36667 | 3 343,46453 | 8 972,89649 | 11 469,83684 |
| EMHR_SF_r0.05_d0.25_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | Độ chính xác của cảnh báo | Precision (%) | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.25_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.25_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.25_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 202,00000 | 101,72309 | 1 164,01598 | 1 239,98402 |
| EMHR_SF_r0.05_d0.25_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 48 806 912,00000 | 4 827 889,74286 | 47 004 148,34243 | 50 609 675,65757 |
| EMHR_SF_r0.05_d0.25_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.25_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.25_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.25_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.05_d0.25_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 34,20031 | 5,24594 | 32,24145 | 36,15918 |
| SF3_r0.05_d0.25_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,65063 | 1,87517 | 12,95043 | 14,35083 |
| SF3_r0.05_d0.25_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,65063 | 1,87517 | 12,95043 | 14,35083 |
| SF3_r0.05_d0.25_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,20201 | 0,89867 | 8,86644 | 9,53758 |
| SF3_r0.05_d0.25_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 10,29883 | 0,65335 | 10,05487 | 10,54280 |
| SF3_r0.05_d0.25_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,51436 | 0,15951 | 2,45480 | 2,57393 |
| SF3_r0.05_d0.25_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 453,66667 | 557,10758 | 2 245,63928 | 2 661,69405 |
| SF3_r0.05_d0.25_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 11 352,83333 | 3 783,92632 | 9 939,89202 | 12 765,77464 |
| SF3_r0.05_d0.25_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 84,78261 | 7,88996 | 81,83645 | 87,72877 |
| SF3_r0.05_d0.25_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 9,75800 | 2,95102 | 8,65607 | 10,85993 |
| SF3_r0.05_d0.25_random | Độ chính xác của cảnh báo | Precision (%) | 30 | 0 | 33,13096 | 7,03304 | 30,50478 | 35,75714 |
| SF3_r0.05_d0.25_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 47,25745 | 7,68121 | 44,38924 | 50,12566 |
| SF3_r0.05_d0.25_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 86,28148 | 2,81995 | 85,22850 | 87,33447 |
| SF3_r0.05_d0.25_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 2 119,42029 | 759,89485 | 1 835,67089 | 2 403,16969 |
| SF3_r0.05_d0.25_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 2 119,42029 | 759,89485 | 1 835,67089 | 2 403,16969 |
| SF3_r0.05_d0.25_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,84783 | 0,07890 | 0,81836 | 0,87729 |
| SF3_r0.05_d0.25_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,84783 | 0,07890 | 0,81836 | 0,87729 |
| SF3_r0.05_d0.25_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 481,40000 | 96,98617 | 445,18477 | 517,61523 |
| SF3_r0.05_d0.25_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 205,00000 | 99,43808 | 1 167,86921 | 1 242,13079 |
| SF3_r0.05_d0.25_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 49 437 286,40000 | 4 998 073,02505 | 47 570 975,26048 | 51 303 597,53952 |
| SF3_r0.05_d0.25_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.05_d0.25_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.05_d0.25_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.05_d0.25_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.75_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 34,11147 | 5,29452 | 32,13447 | 36,08848 |
| EMHR_SF_r0.05_d0.75_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,48388 | 1,87410 | 12,78408 | 14,18368 |
| EMHR_SF_r0.05_d0.75_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,48388 | 1,87410 | 12,78408 | 14,18368 |
| EMHR_SF_r0.05_d0.75_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,65366 | 1,01257 | 9,27556 | 10,03176 |
| EMHR_SF_r0.05_d0.75_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 9,67706 | 0,60232 | 9,45215 | 9,90197 |
| EMHR_SF_r0.05_d0.75_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,36256 | 0,14705 | 2,30765 | 2,41747 |
| EMHR_SF_r0.05_d0.75_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 1 994,40000 | 359,85319 | 1 860,02861 | 2 128,77139 |
| EMHR_SF_r0.05_d0.75_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 9 302,83333 | 2 827,91730 | 8 246,87166 | 10 358,79501 |
| EMHR_SF_r0.05_d0.75_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | Độ chính xác của cảnh báo | Precision (%) | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.75_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.75_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.75_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 217,00000 | 101,40904 | 1 179,13324 | 1 254,86676 |
| EMHR_SF_r0.05_d0.75_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 45 913 156,26667 | 5 264 605,99123 | 43 947 320,08193 | 47 878 992,45140 |
| EMHR_SF_r0.05_d0.75_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.75_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.75_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.75_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.05_d0.75_random | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 34,04946 | 5,26887 | 32,08203 | 36,01688 |
| SF3_r0.05_d0.75_random | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 13,55985 | 1,87636 | 12,85920 | 14,26049 |
| SF3_r0.05_d0.75_random | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 13,55985 | 1,87636 | 12,85920 | 14,26049 |
| SF3_r0.05_d0.75_random | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 9,61732 | 1,08774 | 9,21115 | 10,02349 |
| SF3_r0.05_d0.75_random | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 10,08117 | 0,63656 | 9,84348 | 10,31887 |
| SF3_r0.05_d0.75_random | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,46122 | 0,15541 | 2,40319 | 2,51926 |
| SF3_r0.05_d0.75_random | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 439,73333 | 593,44273 | 2 218,13818 | 2 661,32849 |
| SF3_r0.05_d0.75_random | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 10 813,13333 | 3 997,18117 | 9 320,56136 | 12 305,70531 |
| SF3_r0.05_d0.75_random | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 85,07246 | 7,54651 | 82,25455 | 87,89038 |
| SF3_r0.05_d0.75_random | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 12,79469 | 3,48314 | 11,49407 | 14,09532 |
| SF3_r0.05_d0.75_random | Độ chính xác của cảnh báo | Precision (%) | 30 | 0 | 27,28777 | 5,19501 | 25,34792 | 29,22762 |
| SF3_r0.05_d0.75_random | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 41,01119 | 5,93491 | 38,79506 | 43,22732 |
| SF3_r0.05_d0.75_random | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 86,84444 | 2,63868 | 85,85915 | 87,82974 |
| SF3_r0.05_d0.75_random | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 2 063,13043 | 745,11459 | 1 784,90007 | 2 341,36080 |
| SF3_r0.05_d0.75_random | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 2 063,13043 | 745,11459 | 1 784,90007 | 2 341,36080 |
| SF3_r0.05_d0.75_random | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,85072 | 0,07547 | 0,82255 | 0,87890 |
| SF3_r0.05_d0.75_random | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,85072 | 0,07547 | 0,82255 | 0,87890 |
| SF3_r0.05_d0.75_random | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 694,10000 | 142,97295 | 640,71302 | 747,48698 |
| SF3_r0.05_d0.75_random | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 205,00000 | 99,26454 | 1 167,93401 | 1 242,06599 |
| SF3_r0.05_d0.75_random | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 48 278 903,46667 | 5 144 171,74592 | 46 358 038,16820 | 50 199 768,76513 |
| SF3_r0.05_d0.75_random | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.05_d0.75_random | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.05_d0.75_random | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.05_d0.75_random | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.5_near_sink | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 30,84727 | 4,82205 | 29,04669 | 32,64786 |
| EMHR_SF_r0.05_d0.5_near_sink | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 12,28421 | 1,74522 | 11,63254 | 12,93589 |
| EMHR_SF_r0.05_d0.5_near_sink | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 12,28421 | 1,74522 | 11,63254 | 12,93589 |
| EMHR_SF_r0.05_d0.5_near_sink | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 10,11803 | 1,13136 | 9,69558 | 10,54049 |
| EMHR_SF_r0.05_d0.5_near_sink | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 9,81916 | 0,52822 | 9,62192 | 10,01640 |
| EMHR_SF_r0.05_d0.5_near_sink | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,39726 | 0,12896 | 2,34910 | 2,44541 |
| EMHR_SF_r0.05_d0.5_near_sink | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 360,83333 | 548,71066 | 2 155,94141 | 2 565,72526 |
| EMHR_SF_r0.05_d0.5_near_sink | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 10 828,46667 | 3 790,49738 | 9 413,07168 | 12 243,86165 |
| EMHR_SF_r0.05_d0.5_near_sink | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | Độ chính xác của cảnh báo | Precision (%) | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.5_near_sink | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 195,33333 | 103,08126 | 1 156,84216 | 1 233,82451 |
| EMHR_SF_r0.05_d0.5_near_sink | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 44 314 862,93333 | 5 069 078,72780 | 42 422 037,82866 | 46 207 688,03800 |
| EMHR_SF_r0.05_d0.5_near_sink | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| EMHR_SF_r0.05_d0.5_near_sink | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.05_d0.5_near_sink | Tỷ lệ giao gói PDR | PDR (%) | 30 | 0 | 30,13954 | 4,85034 | 28,32839 | 31,95069 |
| SF3_r0.05_d0.5_near_sink | Thông lượng tại sink | Thông lượng (kbit/s) | 30 | 0 | 12,21897 | 1,82069 | 11,53911 | 12,89882 |
| SF3_r0.05_d0.5_near_sink | Tốc độ payload hữu ích | Goodput (kbit/s) | 30 | 0 | 12,21897 | 1,82069 | 11,53911 | 12,89882 |
| SF3_r0.05_d0.5_near_sink | Năng lượng trên bit nhận thành công | Năng lượng (µJ/bit payload) | 30 | 0 | 10,27033 | 1,25667 | 9,80108 | 10,73958 |
| SF3_r0.05_d0.5_near_sink | Độ trễ của gói nhận thành công | Độ trễ đầu cuối (ms) | 30 | 0 | 10,42443 | 0,65561 | 10,17962 | 10,66924 |
| SF3_r0.05_d0.5_near_sink | Số hop của gói nhận thành công | Số hop trung bình | 30 | 0 | 2,54503 | 0,16006 | 2,48526 | 2,60479 |
| SF3_r0.05_d0.5_near_sink | Quyết định tìm lại tuyến | Số quyết định trong một lượt | 30 | 0 | 2 907,53333 | 645,35901 | 2 666,55232 | 3 148,51435 |
| SF3_r0.05_d0.5_near_sink | Số cạnh có hướng thay đổi | Tổng số cạnh thêm và bớt | 30 | 0 | 13 907,43333 | 4 410,71070 | 12 260,44689 | 15 554,41978 |
| SF3_r0.05_d0.5_near_sink | Phát hiện đúng nút tấn công | TPR / Recall (%) | 30 | 0 | 80,57971 | 10,51030 | 76,65510 | 84,50432 |
| SF3_r0.05_d0.5_near_sink | Báo nhầm sensor lành | FPR (%) | 30 | 0 | 10,68696 | 3,05069 | 9,54782 | 11,82611 |
| SF3_r0.05_d0.5_near_sink | Độ chính xác của cảnh báo | Precision (%) | 30 | 0 | 29,75777 | 5,77022 | 27,60313 | 31,91240 |
| SF3_r0.05_d0.5_near_sink | Trung bình điều hòa Precision–Recall | F1 (%) | 30 | 0 | 43,13934 | 6,81400 | 40,59495 | 45,68374 |
| SF3_r0.05_d0.5_near_sink | Nút có đủ quan sát phát hiện | Độ bao phủ quan sát (%) | 30 | 0 | 87,95556 | 2,76474 | 86,92319 | 88,98792 |
| SF3_r0.05_d0.5_near_sink | Độ trễ phát hiện giới hạn tại 10.000 s | Trễ giới hạn gồm chưa phát hiện (s) | 30 | 0 | 2 412,75362 | 1 042,70850 | 2 023,39987 | 2 802,10737 |
| SF3_r0.05_d0.5_near_sink | isolation_capped_delay_s | đơn vị gốc trong CSV | 30 | 0 | 2 412,75362 | 1 042,70850 | 2 023,39987 | 2 802,10737 |
| SF3_r0.05_d0.5_near_sink | detection_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,80580 | 0,10510 | 0,76655 | 0,84504 |
| SF3_r0.05_d0.5_near_sink | isolation_event_coverage | đơn vị gốc trong CSV | 30 | 0 | 0,80580 | 0,10510 | 0,76655 | 0,84504 |
| SF3_r0.05_d0.5_near_sink | Quyết định cách ly tạm thời | Số quyết định trong một lượt | 30 | 0 | 1 586,36667 | 312,70935 | 1 469,59908 | 1 703,13426 |
| SF3_r0.05_d0.5_near_sink | Thời gian giới hạn min(FND, 10.000 s) | Thời gian giới hạn (s) | 30 | 0 | 1 198,00000 | 101,21333 | 1 160,20632 | 1 235,79368 |
| SF3_r0.05_d0.5_near_sink | FND_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 47 217 152,00000 | 5 469 022,39543 | 45 174 985,47548 | 49 259 318,52452 |
| SF3_r0.05_d0.5_near_sink | HND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.05_d0.5_near_sink | HND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| SF3_r0.05_d0.5_near_sink | LND_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 10 000,00000 | 0,00000 | 10 000,00000 | 10 000,00000 |
| SF3_r0.05_d0.5_near_sink | LND_payload_bits | đơn vị gốc trong CSV | 0 | 30 | NA | NA | NA | NA |
| MHR_r0_d0_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 125,67487 | 17,01619 | 119,32092 | 132,02882 |
| MHR_r0_d0_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 308 780 544,00000 | 17 663 680,17289 | 302 184 817,42571 | 315 376 270,57429 |
| MHR_r0_d0_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 30 878,05440 | 1 766,36802 | 30 218,48174 | 31 537,62706 |
| MHR_r0_d0_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,37418 | 0,04668 | 0,35675 | 0,39161 |
| MHR_r0_d0_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 421,23258 | 121,57772 | 1 375,83471 | 1 466,63044 |
| MHR_r0_d0_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 828,76742 | 121,57772 | 783,36956 | 874,16529 |
| MHR_r0_d0_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 2 251,35613 | 794,60148 | 1 954,64707 | 2 548,06520 |
| MHR_r0_d0_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 2 251,35613 | 794,60148 | 1 954,64707 | 2 548,06520 |
| MHR_r0_d0_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 261,06667 | 25,77346 | 251,44270 | 270,69063 |
| MHR_r0_d0_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,58015 | 0,05727 | 0,55876 | 0,60153 |
| MHR_r0_d0_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| MHR_r0_d0_random | generated | đơn vị gốc trong CSV | 30 | 0 | 301 543,50000 | 17 249,68767 | 295 102,36077 | 307 984,63923 |
| MHR_r0_d0_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 122 729,36667 | 16 617,37493 | 116 524,33689 | 128 934,39644 |
| MHR_r0_d0_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 178 771,86667 | 29 399,11473 | 167 794,05681 | 189 749,67652 |
| MHR_r0_d0_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 42,26667 | 8,30842 | 39,16425 | 45,36908 |
| MHR_r0_d0_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 125 674 871,46667 | 17 016 191,93215 | 119 320 920,97495 | 132 028 821,95839 |
| MHR_r0_d0_random | TP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_r0_d0_random | FP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_r0_d0_random | TN | đơn vị gốc trong CSV | 30 | 0 | 450,00000 | 0,00000 | 450,00000 | 450,00000 |
| MHR_r0_d0_random | FN | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_r0_d0_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 42,26667 | 8,30842 | 39,16425 | 45,36908 |
| MHR_r0_d0_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 42,26667 | 8,30842 | 39,16425 | 45,36908 |
| MHR_r0_d0_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_r0_d0_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_r0_d0_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_r0_d0_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_r0_d0_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 137,19211 | 18,57968 | 130,25434 | 144,12987 |
| EMHR_r0_d0_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 399 979 281,06667 | 8 546 322,10228 | 396 788 031,94696 | 403 170 530,18637 |
| EMHR_r0_d0_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 997,92811 | 854,63221 | 39 678,80319 | 40 317,05302 |
| EMHR_r0_d0_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,35855 | 0,04648 | 0,34119 | 0,37590 |
| EMHR_r0_d0_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 228,27387 | 116,05606 | 1 184,93783 | 1 271,60992 |
| EMHR_r0_d0_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 1 021,72613 | 116,05606 | 978,39008 | 1 065,06217 |
| EMHR_r0_d0_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 605,33333 | 933,42430 | 9 256,78697 | 9 953,87969 |
| EMHR_r0_d0_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 1 875,35013 | 572,74258 | 1 661,48453 | 2 089,21572 |
| EMHR_r0_d0_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 352,03333 | 15,60832 | 346,20509 | 357,86157 |
| EMHR_r0_d0_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,78230 | 0,03469 | 0,76934 | 0,79525 |
| EMHR_r0_d0_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| EMHR_r0_d0_random | generated | đơn vị gốc trong CSV | 30 | 0 | 390 604,76667 | 8 346,01768 | 387 488,31245 | 393 721,22089 |
| EMHR_r0_d0_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 133 976,66667 | 18 144,21902 | 127 201,50394 | 140 751,82940 |
| EMHR_r0_d0_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 256 581,36667 | 24 605,53974 | 247 393,50713 | 265 769,22620 |
| EMHR_r0_d0_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 46,73333 | 9,35113 | 43,24156 | 50,22510 |
| EMHR_r0_d0_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 137 192 106,66667 | 18 579 680,27564 | 130 254 340,03274 | 144 129 873,30060 |
| EMHR_r0_d0_random | TP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_r0_d0_random | FP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_r0_d0_random | TN | đơn vị gốc trong CSV | 30 | 0 | 450,00000 | 0,00000 | 450,00000 | 450,00000 |
| EMHR_r0_d0_random | FN | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_r0_d0_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 283,73333 | 118,66584 | 239,42278 | 328,04389 |
| EMHR_r0_d0_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 46,73333 | 9,35113 | 43,24156 | 50,22510 |
| EMHR_r0_d0_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_r0_d0_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_r0_d0_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_r0_d0_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 124,27493 | 17,09459 | 117,89170 | 130,65815 |
| MHR_SF_r0.05_d0.5_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 308 059 750,40000 | 17 453 476,00574 | 301 542 515,35170 | 314 576 985,44830 |
| MHR_SF_r0.05_d0.5_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 30 805,97504 | 1 745,34760 | 30 154,25154 | 31 457,69854 |
| MHR_SF_r0.05_d0.5_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,37811 | 0,04524 | 0,36121 | 0,39500 |
| MHR_SF_r0.05_d0.5_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 446,30843 | 122,21719 | 1 400,67178 | 1 491,94508 |
| MHR_SF_r0.05_d0.5_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 803,69157 | 122,21719 | 758,05492 | 849,32822 |
| MHR_SF_r0.05_d0.5_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 2 449,34699 | 840,75344 | 2 135,40449 | 2 763,28948 |
| MHR_SF_r0.05_d0.5_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 2 449,34699 | 840,75344 | 2 135,40449 | 2 763,28948 |
| MHR_SF_r0.05_d0.5_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 257,20000 | 26,39801 | 247,34282 | 267,05718 |
| MHR_SF_r0.05_d0.5_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,57156 | 0,05866 | 0,54965 | 0,59346 |
| MHR_SF_r0.05_d0.5_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| MHR_SF_r0.05_d0.5_random | generated | đơn vị gốc trong CSV | 30 | 0 | 300 839,60000 | 17 044,41016 | 294 475,11265 | 307 204,08735 |
| MHR_SF_r0.05_d0.5_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 121 362,23333 | 16 693,93083 | 115 128,61712 | 127 595,84955 |
| MHR_SF_r0.05_d0.5_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 179 434,50000 | 29 337,93343 | 168 479,53562 | 190 389,46438 |
| MHR_SF_r0.05_d0.5_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 42,86667 | 8,32004 | 39,75991 | 45,97342 |
| MHR_SF_r0.05_d0.5_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 124 274 926,93333 | 17 094 585,16486 | 117 891 703,92744 | 130 658 149,93923 |
| MHR_SF_r0.05_d0.5_random | TP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | FP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | TN | đơn vị gốc trong CSV | 30 | 0 | 427,00000 | 0,00000 | 427,00000 | 427,00000 |
| MHR_SF_r0.05_d0.5_random | FN | đơn vị gốc trong CSV | 30 | 0 | 23,00000 | 0,00000 | 23,00000 | 23,00000 |
| MHR_SF_r0.05_d0.5_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 42,86667 | 8,32004 | 39,75991 | 45,97342 |
| MHR_SF_r0.05_d0.5_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 42,86667 | 8,32004 | 39,75991 | 45,97342 |
| MHR_SF_r0.05_d0.5_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| MHR_SF_r0.05_d0.5_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 135,88569 | 18,66969 | 128,91431 | 142,85706 |
| EMHR_SF_r0.05_d0.5_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 398 576 947,20000 | 8 902 113,27536 | 395 252 843,47287 | 401 901 050,92713 |
| EMHR_SF_r0.05_d0.5_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 857,69472 | 890,21133 | 39 525,28435 | 40 190,10509 |
| EMHR_SF_r0.05_d0.5_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,36326 | 0,04622 | 0,34600 | 0,38052 |
| EMHR_SF_r0.05_d0.5_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 255,76497 | 120,52169 | 1 210,76144 | 1 300,76851 |
| EMHR_SF_r0.05_d0.5_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 994,23503 | 120,52169 | 949,23149 | 1 039,23856 |
| EMHR_SF_r0.05_d0.5_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 625,00000 | 973,71578 | 9 261,40855 | 9 988,59145 |
| EMHR_SF_r0.05_d0.5_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 2 066,35067 | 618,99815 | 1 835,21297 | 2 297,48838 |
| EMHR_SF_r0.05_d0.5_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 348,83333 | 16,70656 | 342,59500 | 355,07167 |
| EMHR_SF_r0.05_d0.5_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,77519 | 0,03713 | 0,76132 | 0,78905 |
| EMHR_SF_r0.05_d0.5_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| EMHR_SF_r0.05_d0.5_random | generated | đơn vị gốc trong CSV | 30 | 0 | 389 235,30000 | 8 693,47000 | 385 989,10495 | 392 481,49505 |
| EMHR_SF_r0.05_d0.5_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 132 700,86667 | 18 232,11545 | 125 892,88287 | 139 508,85046 |
| EMHR_SF_r0.05_d0.5_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 256 487,23333 | 25 128,81253 | 247 103,98052 | 265 870,48614 |
| EMHR_SF_r0.05_d0.5_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 47,20000 | 9,21169 | 43,76030 | 50,63970 |
| EMHR_SF_r0.05_d0.5_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 135 885 687,46667 | 18 669 686,22059 | 128 914 312,06055 | 142 857 062,87278 |
| EMHR_SF_r0.05_d0.5_random | TP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | FP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | TN | đơn vị gốc trong CSV | 30 | 0 | 427,00000 | 0,00000 | 427,00000 | 427,00000 |
| EMHR_SF_r0.05_d0.5_random | FN | đơn vị gốc trong CSV | 30 | 0 | 23,00000 | 0,00000 | 23,00000 | 23,00000 |
| EMHR_SF_r0.05_d0.5_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 289,16667 | 111,71271 | 247,45245 | 330,88088 |
| EMHR_SF_r0.05_d0.5_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 47,20000 | 9,21169 | 43,76030 | 50,63970 |
| EMHR_SF_r0.05_d0.5_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF2_r0.05_d0.5_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 135,88569 | 18,66969 | 128,91431 | 142,85706 |
| SF2_r0.05_d0.5_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 398 576 947,20000 | 8 902 113,27536 | 395 252 843,47287 | 401 901 050,92713 |
| SF2_r0.05_d0.5_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 857,69472 | 890,21133 | 39 525,28435 | 40 190,10509 |
| SF2_r0.05_d0.5_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,36326 | 0,04622 | 0,34600 | 0,38052 |
| SF2_r0.05_d0.5_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 255,76497 | 120,52169 | 1 210,76144 | 1 300,76851 |
| SF2_r0.05_d0.5_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 994,23503 | 120,52169 | 949,23149 | 1 039,23856 |
| SF2_r0.05_d0.5_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 625,00000 | 973,71578 | 9 261,40855 | 9 988,59145 |
| SF2_r0.05_d0.5_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 2 066,35067 | 618,99815 | 1 835,21297 | 2 297,48838 |
| SF2_r0.05_d0.5_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 348,83333 | 16,70656 | 342,59500 | 355,07167 |
| SF2_r0.05_d0.5_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,77519 | 0,03713 | 0,76132 | 0,78905 |
| SF2_r0.05_d0.5_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| SF2_r0.05_d0.5_random | generated | đơn vị gốc trong CSV | 30 | 0 | 389 235,30000 | 8 693,47000 | 385 989,10495 | 392 481,49505 |
| SF2_r0.05_d0.5_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 132 700,86667 | 18 232,11545 | 125 892,88287 | 139 508,85046 |
| SF2_r0.05_d0.5_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 256 487,23333 | 25 128,81253 | 247 103,98052 | 265 870,48614 |
| SF2_r0.05_d0.5_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 47,20000 | 9,21169 | 43,76030 | 50,63970 |
| SF2_r0.05_d0.5_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 135 885 687,46667 | 18 669 686,22059 | 128 914 312,06055 | 142 857 062,87278 |
| SF2_r0.05_d0.5_random | TP | đơn vị gốc trong CSV | 30 | 0 | 19,30000 | 2,13590 | 18,50244 | 20,09756 |
| SF2_r0.05_d0.5_random | FP | đơn vị gốc trong CSV | 30 | 0 | 32,33333 | 10,54165 | 28,39702 | 36,26965 |
| SF2_r0.05_d0.5_random | TN | đơn vị gốc trong CSV | 30 | 0 | 394,66667 | 10,54165 | 390,73035 | 398,60298 |
| SF2_r0.05_d0.5_random | FN | đơn vị gốc trong CSV | 30 | 0 | 3,70000 | 2,13590 | 2,90244 | 4,49756 |
| SF2_r0.05_d0.5_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 289,16667 | 111,71271 | 247,45245 | 330,88088 |
| SF2_r0.05_d0.5_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 47,20000 | 9,21169 | 43,76030 | 50,63970 |
| SF2_r0.05_d0.5_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 382,10000 | 86,06748 | 349,96188 | 414,23812 |
| SF2_r0.05_d0.5_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF2_r0.05_d0.5_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 51,63333 | 10,44025 | 47,73488 | 55,53179 |
| SF2_r0.05_d0.5_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 51,63333 | 10,44025 | 47,73488 | 55,53179 |
| SF3_r0.05_d0.5_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 136,07089 | 18,77110 | 129,06165 | 143,08014 |
| SF3_r0.05_d0.5_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 399 547 153,06667 | 8 827 359,30109 | 396 250 962,93227 | 402 843 343,20106 |
| SF3_r0.05_d0.5_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 954,71531 | 882,73593 | 39 625,09629 | 40 284,33432 |
| SF3_r0.05_d0.5_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,37011 | 0,05001 | 0,35144 | 0,38878 |
| SF3_r0.05_d0.5_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 259,79818 | 108,36016 | 1 219,33584 | 1 300,26053 |
| SF3_r0.05_d0.5_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 990,20182 | 108,36016 | 949,73947 | 1 030,66416 |
| SF3_r0.05_d0.5_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 727,00000 | 846,27847 | 9 410,99443 | 10 043,00557 |
| SF3_r0.05_d0.5_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 1 897,01925 | 586,89011 | 1 677,87088 | 2 116,16762 |
| SF3_r0.05_d0.5_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 350,20000 | 16,40732 | 344,07341 | 356,32659 |
| SF3_r0.05_d0.5_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,77822 | 0,03646 | 0,76461 | 0,79184 |
| SF3_r0.05_d0.5_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| SF3_r0.05_d0.5_random | generated | đơn vị gốc trong CSV | 30 | 0 | 390 182,76667 | 8 620,46807 | 386 963,83099 | 393 401,70234 |
| SF3_r0.05_d0.5_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 132 881,73333 | 18 331,14895 | 126 036,76982 | 139 726,69684 |
| SF3_r0.05_d0.5_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 257 254,26667 | 25 116,35423 | 247 875,66586 | 266 632,86747 |
| SF3_r0.05_d0.5_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 46,76667 | 9,27616 | 43,30289 | 50,23044 |
| SF3_r0.05_d0.5_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 136 070 894,93333 | 18 771 096,52372 | 129 061 652,29770 | 143 080 137,56897 |
| SF3_r0.05_d0.5_random | TP | đơn vị gốc trong CSV | 30 | 0 | 19,60000 | 1,71404 | 18,95997 | 20,24003 |
| SF3_r0.05_d0.5_random | FP | đơn vị gốc trong CSV | 30 | 0 | 47,73333 | 12,73045 | 42,97971 | 52,48696 |
| SF3_r0.05_d0.5_random | TN | đơn vị gốc trong CSV | 30 | 0 | 379,26667 | 12,73045 | 374,51304 | 384,02029 |
| SF3_r0.05_d0.5_random | FN | đơn vị gốc trong CSV | 30 | 0 | 3,40000 | 1,71404 | 2,75997 | 4,04003 |
| SF3_r0.05_d0.5_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 304,16667 | 103,95891 | 265,34777 | 342,98556 |
| SF3_r0.05_d0.5_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 46,76667 | 9,27616 | 43,30289 | 50,23044 |
| SF3_r0.05_d0.5_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 561,63333 | 117,27494 | 517,84215 | 605,42452 |
| SF3_r0.05_d0.5_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.05_d0.5_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 67,33333 | 13,23874 | 62,38990 | 72,27676 |
| SF3_r0.05_d0.5_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 67,33333 | 13,23874 | 62,38990 | 72,27676 |
| EMHR_SF_r0.02_d0.5_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 136,56139 | 18,60503 | 129,61416 | 143,50862 |
| EMHR_SF_r0.02_d0.5_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 399 621 358,93333 | 8 715 579,52291 | 396 366 908,05407 | 402 875 809,81259 |
| EMHR_SF_r0.02_d0.5_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 962,13589 | 871,55795 | 39 636,69081 | 40 287,58098 |
| EMHR_SF_r0.02_d0.5_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,35940 | 0,04517 | 0,34254 | 0,37627 |
| EMHR_SF_r0.02_d0.5_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 237,05355 | 117,64585 | 1 193,12387 | 1 280,98323 |
| EMHR_SF_r0.02_d0.5_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 1 012,94645 | 117,64585 | 969,01677 | 1 056,87613 |
| EMHR_SF_r0.02_d0.5_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 642,33333 | 936,02860 | 9 292,81451 | 9 991,85216 |
| EMHR_SF_r0.02_d0.5_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 1 948,35081 | 594,07773 | 1 726,51854 | 2 170,18308 |
| EMHR_SF_r0.02_d0.5_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 351,16667 | 16,31180 | 345,07574 | 357,25759 |
| EMHR_SF_r0.02_d0.5_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,78037 | 0,03625 | 0,76683 | 0,79391 |
| EMHR_SF_r0.02_d0.5_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| EMHR_SF_r0.02_d0.5_random | generated | đơn vị gốc trong CSV | 30 | 0 | 390 255,23333 | 8 511,30813 | 387 077,05865 | 393 433,40802 |
| EMHR_SF_r0.02_d0.5_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 133 360,73333 | 18 168,96997 | 126 576,32845 | 140 145,13822 |
| EMHR_SF_r0.02_d0.5_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 256 847,46667 | 24 978,26812 | 247 520,42806 | 266 174,50527 |
| EMHR_SF_r0.02_d0.5_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 47,03333 | 9,15568 | 43,61455 | 50,45212 |
| EMHR_SF_r0.02_d0.5_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 136 561 390,93333 | 18 605 025,24978 | 129 614 160,33053 | 143 508 621,53614 |
| EMHR_SF_r0.02_d0.5_random | TP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | FP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | TN | đơn vị gốc trong CSV | 30 | 0 | 441,00000 | 0,00000 | 441,00000 | 441,00000 |
| EMHR_SF_r0.02_d0.5_random | FN | đơn vị gốc trong CSV | 30 | 0 | 9,00000 | 0,00000 | 9,00000 | 9,00000 |
| EMHR_SF_r0.02_d0.5_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 292,56667 | 112,41140 | 250,59156 | 334,54177 |
| EMHR_SF_r0.02_d0.5_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 47,03333 | 9,15568 | 43,61455 | 50,45212 |
| EMHR_SF_r0.02_d0.5_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.02_d0.5_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.02_d0.5_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 136,81531 | 18,83339 | 129,78281 | 143,84781 |
| SF3_r0.02_d0.5_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 399 919 445,33333 | 9 010 242,30581 | 396 554 965,56267 | 403 283 925,10400 |
| SF3_r0.02_d0.5_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 991,94453 | 901,02423 | 39 655,49656 | 40 328,39251 |
| SF3_r0.02_d0.5_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,36215 | 0,04661 | 0,34474 | 0,37955 |
| SF3_r0.02_d0.5_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 239,54663 | 114,59133 | 1 196,75752 | 1 282,33574 |
| SF3_r0.02_d0.5_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 1 010,45337 | 114,59133 | 967,66426 | 1 053,24248 |
| SF3_r0.02_d0.5_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 585,00000 | 903,25751 | 9 247,71810 | 9 922,28190 |
| SF3_r0.02_d0.5_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 1 889,01584 | 587,38103 | 1 669,68416 | 2 108,34752 |
| SF3_r0.02_d0.5_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 351,26667 | 16,50900 | 345,10210 | 357,43123 |
| SF3_r0.02_d0.5_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,78059 | 0,03669 | 0,76689 | 0,79429 |
| SF3_r0.02_d0.5_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| SF3_r0.02_d0.5_random | generated | đơn vị gốc trong CSV | 30 | 0 | 390 546,33333 | 8 799,06475 | 387 260,70856 | 393 831,95811 |
| SF3_r0.02_d0.5_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 133 608,70000 | 18 391,98255 | 126 741,02085 | 140 476,37915 |
| SF3_r0.02_d0.5_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 256 891,00000 | 25 232,35506 | 247 469,08378 | 266 312,91622 |
| SF3_r0.02_d0.5_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 46,63333 | 9,24936 | 43,17957 | 50,08710 |
| SF3_r0.02_d0.5_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 136 815 308,80000 | 18 833 390,12624 | 129 782 805,35090 | 143 847 812,24910 |
| SF3_r0.02_d0.5_random | TP | đơn vị gốc trong CSV | 30 | 0 | 7,76667 | 0,93526 | 7,41743 | 8,11590 |
| SF3_r0.02_d0.5_random | FP | đơn vị gốc trong CSV | 30 | 0 | 42,13333 | 14,56669 | 36,69404 | 47,57263 |
| SF3_r0.02_d0.5_random | TN | đơn vị gốc trong CSV | 30 | 0 | 398,86667 | 14,56669 | 393,42737 | 404,30596 |
| SF3_r0.02_d0.5_random | FN | đơn vị gốc trong CSV | 30 | 0 | 1,23333 | 0,93526 | 0,88410 | 1,58257 |
| SF3_r0.02_d0.5_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 275,46667 | 126,14407 | 228,36370 | 322,56964 |
| SF3_r0.02_d0.5_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 46,63333 | 9,24936 | 43,17957 | 50,08710 |
| SF3_r0.02_d0.5_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 236,20000 | 71,84821 | 209,37144 | 263,02856 |
| SF3_r0.02_d0.5_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.02_d0.5_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 49,90000 | 14,77264 | 44,38380 | 55,41620 |
| SF3_r0.02_d0.5_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 49,90000 | 14,77264 | 44,38380 | 55,41620 |
| EMHR_SF_r0.1_d0.5_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 134,44861 | 18,45225 | 127,55842 | 141,33879 |
| EMHR_SF_r0.1_d0.5_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 398 113 177,60000 | 9 254 510,07766 | 394 657 486,74431 | 401 568 868,45569 |
| EMHR_SF_r0.1_d0.5_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 811,31776 | 925,45101 | 39 465,74867 | 40 156,88685 |
| EMHR_SF_r0.1_d0.5_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,37073 | 0,04988 | 0,35210 | 0,38935 |
| EMHR_SF_r0.1_d0.5_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 279,98740 | 118,61614 | 1 235,69540 | 1 324,27940 |
| EMHR_SF_r0.1_d0.5_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 970,01260 | 118,61614 | 925,72060 | 1 014,30460 |
| EMHR_SF_r0.1_d0.5_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 631,33333 | 881,81135 | 9 302,05956 | 9 960,60710 |
| EMHR_SF_r0.1_d0.5_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 2 235,34944 | 623,43179 | 2 002,55619 | 2 468,14270 |
| EMHR_SF_r0.1_d0.5_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 347,06667 | 17,41766 | 340,56281 | 353,57053 |
| EMHR_SF_r0.1_d0.5_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,77126 | 0,03871 | 0,75681 | 0,78571 |
| EMHR_SF_r0.1_d0.5_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| EMHR_SF_r0.1_d0.5_random | generated | đơn vị gốc trong CSV | 30 | 0 | 388 782,40000 | 9 037,60750 | 385 407,70190 | 392 157,09810 |
| EMHR_SF_r0.1_d0.5_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 131 297,46667 | 18 019,77877 | 124 568,77069 | 138 026,16264 |
| EMHR_SF_r0.1_d0.5_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 257 437,20000 | 25 508,50220 | 247 912,16874 | 266 962,23126 |
| EMHR_SF_r0.1_d0.5_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 47,73333 | 9,51200 | 44,18149 | 51,28517 |
| EMHR_SF_r0.1_d0.5_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 134 448 605,86667 | 18 452 253,46322 | 127 558 421,18649 | 141 338 790,54685 |
| EMHR_SF_r0.1_d0.5_random | TP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | FP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | TN | đơn vị gốc trong CSV | 30 | 0 | 405,00000 | 0,00000 | 405,00000 | 405,00000 |
| EMHR_SF_r0.1_d0.5_random | FN | đơn vị gốc trong CSV | 30 | 0 | 45,00000 | 0,00000 | 45,00000 | 45,00000 |
| EMHR_SF_r0.1_d0.5_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 279,66667 | 117,07096 | 235,95165 | 323,38168 |
| EMHR_SF_r0.1_d0.5_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 47,73333 | 9,51200 | 44,18149 | 51,28517 |
| EMHR_SF_r0.1_d0.5_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.1_d0.5_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.1_d0.5_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 134,78721 | 18,64279 | 127,82588 | 141,74854 |
| SF3_r0.1_d0.5_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 400 201 489,06667 | 8 428 641,29136 | 397 054 182,68394 | 403 348 795,44939 |
| SF3_r0.1_d0.5_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 40 020,14891 | 842,86413 | 39 705,41827 | 40 334,87954 |
| SF3_r0.1_d0.5_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,38460 | 0,05503 | 0,36405 | 0,40515 |
| SF3_r0.1_d0.5_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 287,52239 | 104,60260 | 1 248,46314 | 1 326,58164 |
| SF3_r0.1_d0.5_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 962,47761 | 104,60260 | 923,41836 | 1 001,53686 |
| SF3_r0.1_d0.5_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 810,33333 | 610,45197 | 9 582,38682 | 10 038,27985 |
| SF3_r0.1_d0.5_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 1 908,68018 | 584,87882 | 1 690,28284 | 2 127,07752 |
| SF3_r0.1_d0.5_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 350,03333 | 15,74688 | 344,15335 | 355,91332 |
| SF3_r0.1_d0.5_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,77785 | 0,03499 | 0,76479 | 0,79092 |
| SF3_r0.1_d0.5_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| SF3_r0.1_d0.5_random | generated | đơn vị gốc trong CSV | 30 | 0 | 390 821,76667 | 8 231,09501 | 387 748,22528 | 393 895,30806 |
| SF3_r0.1_d0.5_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 131 628,13333 | 18 205,85245 | 124 829,95630 | 138 426,31036 |
| SF3_r0.1_d0.5_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 259 146,83333 | 24 822,89334 | 249 877,81263 | 268 415,85404 |
| SF3_r0.1_d0.5_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 46,80000 | 8,96122 | 43,45383 | 50,14617 |
| SF3_r0.1_d0.5_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 134 787 208,53333 | 18 642 792,91070 | 127 825 875,25417 | 141 748 541,81250 |
| SF3_r0.1_d0.5_random | TP | đơn vị gốc trong CSV | 30 | 0 | 38,63333 | 1,80962 | 37,95761 | 39,30906 |
| SF3_r0.1_d0.5_random | FP | đơn vị gốc trong CSV | 30 | 0 | 50,16667 | 17,30075 | 43,70646 | 56,62687 |
| SF3_r0.1_d0.5_random | TN | đơn vị gốc trong CSV | 30 | 0 | 354,83333 | 17,30075 | 348,37313 | 361,29354 |
| SF3_r0.1_d0.5_random | FN | đơn vị gốc trong CSV | 30 | 0 | 6,36667 | 1,80962 | 5,69094 | 7,04239 |
| SF3_r0.1_d0.5_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 306,86667 | 101,36575 | 269,01607 | 344,71726 |
| SF3_r0.1_d0.5_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 46,80000 | 8,96122 | 43,45383 | 50,14617 |
| SF3_r0.1_d0.5_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 1 173,23333 | 212,44970 | 1 093,90331 | 1 252,56335 |
| SF3_r0.1_d0.5_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.1_d0.5_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 88,80000 | 16,98153 | 82,45899 | 95,14101 |
| SF3_r0.1_d0.5_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 88,80000 | 16,98153 | 82,45899 | 95,14101 |
| EMHR_SF_r0.05_d0.25_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 136,59638 | 18,61297 | 129,64618 | 143,54657 |
| EMHR_SF_r0.05_d0.25_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 399 772 808,53333 | 8 997 753,94359 | 396 412 991,99376 | 403 132 625,07291 |
| EMHR_SF_r0.05_d0.25_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 977,28085 | 899,77539 | 39 641,29920 | 40 313,26251 |
| EMHR_SF_r0.05_d0.25_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,35965 | 0,04592 | 0,34251 | 0,37680 |
| EMHR_SF_r0.05_d0.25_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 237,06338 | 117,42172 | 1 193,21738 | 1 280,90937 |
| EMHR_SF_r0.05_d0.25_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 1 012,93662 | 117,42172 | 969,09063 | 1 056,78262 |
| EMHR_SF_r0.05_d0.25_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 617,33333 | 985,48757 | 9 249,34623 | 9 985,32044 |
| EMHR_SF_r0.05_d0.25_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 1 944,68701 | 581,64519 | 1 727,49713 | 2 161,87689 |
| EMHR_SF_r0.05_d0.25_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 351,33333 | 16,56613 | 345,14744 | 357,51923 |
| EMHR_SF_r0.05_d0.25_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,78074 | 0,03681 | 0,76699 | 0,79449 |
| EMHR_SF_r0.05_d0.25_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| EMHR_SF_r0.05_d0.25_random | generated | đơn vị gốc trong CSV | 30 | 0 | 390 403,13333 | 8 786,86909 | 387 122,06249 | 393 684,20417 |
| EMHR_SF_r0.05_d0.25_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 133 394,90000 | 18 176,72598 | 126 607,59897 | 140 182,20103 |
| EMHR_SF_r0.05_d0.25_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 256 961,33333 | 25 158,87262 | 247 566,85590 | 266 355,81076 |
| EMHR_SF_r0.05_d0.25_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 46,90000 | 9,26376 | 43,44086 | 50,35914 |
| EMHR_SF_r0.05_d0.25_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 136 596 377,60000 | 18 612 967,40497 | 129 646 181,34771 | 143 546 573,85229 |
| EMHR_SF_r0.05_d0.25_random | TP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | FP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | TN | đơn vị gốc trong CSV | 30 | 0 | 427,00000 | 0,00000 | 427,00000 | 427,00000 |
| EMHR_SF_r0.05_d0.25_random | FN | đơn vị gốc trong CSV | 30 | 0 | 23,00000 | 0,00000 | 23,00000 | 23,00000 |
| EMHR_SF_r0.05_d0.25_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 292,90000 | 112,54343 | 250,87559 | 334,92441 |
| EMHR_SF_r0.05_d0.25_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 46,90000 | 9,26376 | 43,44086 | 50,35914 |
| EMHR_SF_r0.05_d0.25_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.25_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.05_d0.25_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 136,50633 | 18,75168 | 129,50434 | 143,50833 |
| SF3_r0.05_d0.25_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 400 127 214,93333 | 8 667 270,74765 | 396 890 802,84722 | 403 363 627,01945 |
| SF3_r0.05_d0.25_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 40 012,72149 | 866,72707 | 39 689,08028 | 40 336,36270 |
| SF3_r0.05_d0.25_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,36605 | 0,04829 | 0,34802 | 0,38408 |
| SF3_r0.05_d0.25_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 243,63393 | 111,85789 | 1 201,86551 | 1 285,40236 |
| SF3_r0.05_d0.25_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 1 006,36607 | 111,85789 | 964,59764 | 1 048,13449 |
| SF3_r0.05_d0.25_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 685,66667 | 862,90481 | 9 363,45271 | 10 007,88062 |
| SF3_r0.05_d0.25_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 1 874,68087 | 575,11767 | 1 659,92840 | 2 089,43333 |
| SF3_r0.05_d0.25_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 351,43333 | 15,94318 | 345,48005 | 357,38662 |
| SF3_r0.05_d0.25_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,78096 | 0,03543 | 0,76773 | 0,79419 |
| SF3_r0.05_d0.25_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| SF3_r0.05_d0.25_random | generated | đơn vị gốc trong CSV | 30 | 0 | 390 749,23333 | 8 464,13159 | 387 588,67466 | 393 909,79201 |
| SF3_r0.05_d0.25_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 133 306,96667 | 18 312,18450 | 126 469,08460 | 140 144,84874 |
| SF3_r0.05_d0.25_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 257 395,83333 | 24 939,48628 | 248 083,27611 | 266 708,39056 |
| SF3_r0.05_d0.25_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 46,43333 | 9,40903 | 42,91994 | 49,94672 |
| SF3_r0.05_d0.25_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 136 506 333,86667 | 18 751 676,92537 | 129 504 342,62823 | 143 508 325,10510 |
| SF3_r0.05_d0.25_random | TP | đơn vị gốc trong CSV | 30 | 0 | 19,50000 | 1,81469 | 18,82238 | 20,17762 |
| SF3_r0.05_d0.25_random | FP | đơn vị gốc trong CSV | 30 | 0 | 41,66667 | 12,60086 | 36,96143 | 46,37190 |
| SF3_r0.05_d0.25_random | TN | đơn vị gốc trong CSV | 30 | 0 | 385,33333 | 12,60086 | 380,62810 | 390,03857 |
| SF3_r0.05_d0.25_random | FN | đơn vị gốc trong CSV | 30 | 0 | 3,50000 | 1,81469 | 2,82238 | 4,17762 |
| SF3_r0.05_d0.25_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 294,50000 | 111,62089 | 252,82007 | 336,17993 |
| SF3_r0.05_d0.25_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 46,43333 | 9,40903 | 42,91994 | 49,94672 |
| SF3_r0.05_d0.25_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 481,40000 | 96,98617 | 445,18477 | 517,61523 |
| SF3_r0.05_d0.25_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.05_d0.25_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 61,16667 | 12,69288 | 56,42707 | 65,90627 |
| SF3_r0.05_d0.25_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 61,16667 | 12,69288 | 56,42707 | 65,90627 |
| EMHR_SF_r0.05_d0.75_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 134,83882 | 18,74100 | 127,84081 | 141,83682 |
| EMHR_SF_r0.05_d0.75_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 396 306 602,66667 | 9 005 121,24032 | 392 944 035,13328 | 399 669 170,20005 |
| EMHR_SF_r0.05_d0.75_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 630,66027 | 900,51212 | 39 294,40351 | 39 966,91702 |
| EMHR_SF_r0.05_d0.75_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,36785 | 0,04915 | 0,34950 | 0,38620 |
| EMHR_SF_r0.05_d0.75_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 287,88669 | 117,28437 | 1 244,09199 | 1 331,68139 |
| EMHR_SF_r0.05_d0.75_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 962,11331 | 117,28437 | 918,31861 | 1 005,90801 |
| EMHR_SF_r0.05_d0.75_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 661,33333 | 829,80568 | 9 351,47880 | 9 971,18787 |
| EMHR_SF_r0.05_d0.75_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 2 269,34726 | 647,54209 | 2 027,55107 | 2 511,14345 |
| EMHR_SF_r0.05_d0.75_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 344,33333 | 16,95701 | 338,00148 | 350,66519 |
| EMHR_SF_r0.05_d0.75_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,76519 | 0,03768 | 0,75111 | 0,77926 |
| EMHR_SF_r0.05_d0.75_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| EMHR_SF_r0.05_d0.75_random | generated | đơn vị gốc trong CSV | 30 | 0 | 387 018,16667 | 8 794,06371 | 383 734,40931 | 390 301,92402 |
| EMHR_SF_r0.05_d0.75_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 131 678,53333 | 18 301,75455 | 124 844,54587 | 138 512,52079 |
| EMHR_SF_r0.05_d0.75_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 255 291,03333 | 25 087,10401 | 245 923,35474 | 264 658,71192 |
| EMHR_SF_r0.05_d0.75_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 48,60000 | 9,95022 | 44,88453 | 52,31547 |
| EMHR_SF_r0.05_d0.75_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 134 838 818,13333 | 18 740 996,65613 | 127 840 814,97297 | 141 836 821,29370 |
| EMHR_SF_r0.05_d0.75_random | TP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | FP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | TN | đơn vị gốc trong CSV | 30 | 0 | 427,00000 | 0,00000 | 427,00000 | 427,00000 |
| EMHR_SF_r0.05_d0.75_random | FN | đơn vị gốc trong CSV | 30 | 0 | 23,00000 | 0,00000 | 23,00000 | 23,00000 |
| EMHR_SF_r0.05_d0.75_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 276,50000 | 116,13451 | 233,13466 | 319,86534 |
| EMHR_SF_r0.05_d0.75_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 48,60000 | 9,95022 | 44,88453 | 52,31547 |
| EMHR_SF_r0.05_d0.75_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.75_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.05_d0.75_random | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 135,59849 | 18,76363 | 128,59204 | 142,60494 |
| SF3_r0.05_d0.75_random | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 399 261 969,06667 | 8 916 918,75925 | 395 932 336,88099 | 402 591 601,25235 |
| SF3_r0.05_d0.75_random | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 926,19691 | 891,69188 | 39 593,23369 | 40 259,16013 |
| SF3_r0.05_d0.75_random | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,37725 | 0,05366 | 0,35721 | 0,39729 |
| SF3_r0.05_d0.75_random | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 288,15111 | 104,03727 | 1 249,30295 | 1 326,99926 |
| SF3_r0.05_d0.75_random | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 961,84889 | 104,03727 | 923,00074 | 1 000,69705 |
| SF3_r0.05_d0.75_random | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 811,66667 | 718,74452 | 9 543,28305 | 10 080,05028 |
| SF3_r0.05_d0.75_random | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 1 935,01434 | 600,63626 | 1 710,73307 | 2 159,29560 |
| SF3_r0.05_d0.75_random | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 349,00000 | 16,45055 | 342,85726 | 355,14274 |
| SF3_r0.05_d0.75_random | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,77556 | 0,03656 | 0,76191 | 0,78921 |
| SF3_r0.05_d0.75_random | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| SF3_r0.05_d0.75_random | generated | đơn vị gốc trong CSV | 30 | 0 | 389 904,26667 | 8 707,92848 | 386 652,67274 | 393 155,86060 |
| SF3_r0.05_d0.75_random | delivered | đơn vị gốc trong CSV | 30 | 0 | 132 420,40000 | 18 323,85685 | 125 578,15940 | 139 262,64060 |
| SF3_r0.05_d0.75_random | dropped | đơn vị gốc trong CSV | 30 | 0 | 257 436,60000 | 25 107,92650 | 248 061,14616 | 266 812,05384 |
| SF3_r0.05_d0.75_random | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 47,26667 | 9,48659 | 43,72432 | 50,80902 |
| SF3_r0.05_d0.75_random | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 135 598 489,60000 | 18 763 629,41178 | 128 592 035,22979 | 142 604 943,97021 |
| SF3_r0.05_d0.75_random | TP | đơn vị gốc trong CSV | 30 | 0 | 19,56667 | 1,73570 | 18,91855 | 20,21479 |
| SF3_r0.05_d0.75_random | FP | đơn vị gốc trong CSV | 30 | 0 | 54,63333 | 14,87299 | 49,07967 | 60,18700 |
| SF3_r0.05_d0.75_random | TN | đơn vị gốc trong CSV | 30 | 0 | 372,36667 | 14,87299 | 366,81300 | 377,92033 |
| SF3_r0.05_d0.75_random | FN | đơn vị gốc trong CSV | 30 | 0 | 3,43333 | 1,73570 | 2,78521 | 4,08145 |
| SF3_r0.05_d0.75_random | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 324,83333 | 68,56313 | 299,23144 | 350,43523 |
| SF3_r0.05_d0.75_random | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 47,26667 | 9,48659 | 43,72432 | 50,80902 |
| SF3_r0.05_d0.75_random | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 694,10000 | 142,97295 | 640,71302 | 747,48698 |
| SF3_r0.05_d0.75_random | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.05_d0.75_random | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 74,20000 | 15,36768 | 68,46161 | 79,93839 |
| SF3_r0.05_d0.75_random | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 74,20000 | 15,36768 | 68,46161 | 79,93839 |
| EMHR_SF_r0.05_d0.5_near_sink | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 122,84215 | 17,45219 | 116,32539 | 129,35890 |
| EMHR_SF_r0.05_d0.5_near_sink | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 399 149 841,06667 | 8 784 115,99399 | 395 869 798,24852 | 402 429 883,88482 |
| EMHR_SF_r0.05_d0.5_near_sink | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 39 914,98411 | 878,41160 | 39 586,97982 | 40 242,98839 |
| EMHR_SF_r0.05_d0.5_near_sink | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,40596 | 0,04954 | 0,38746 | 0,42446 |
| EMHR_SF_r0.05_d0.5_near_sink | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 228,29985 | 113,45245 | 1 185,93601 | 1 270,66369 |
| EMHR_SF_r0.05_d0.5_near_sink | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 1 021,70015 | 113,45245 | 979,33631 | 1 064,06399 |
| EMHR_SF_r0.05_d0.5_near_sink | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 546,00000 | 963,55878 | 9 186,20124 | 9 905,79876 |
| EMHR_SF_r0.05_d0.5_near_sink | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 1 879,68141 | 572,17622 | 1 666,02730 | 2 093,33553 |
| EMHR_SF_r0.05_d0.5_near_sink | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 350,56667 | 16,12811 | 344,54433 | 356,58900 |
| EMHR_SF_r0.05_d0.5_near_sink | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,77904 | 0,03584 | 0,76565 | 0,79242 |
| EMHR_SF_r0.05_d0.5_near_sink | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | generated | đơn vị gốc trong CSV | 30 | 0 | 389 794,76667 | 8 578,23828 | 386 591,59985 | 392 997,93348 |
| EMHR_SF_r0.05_d0.5_near_sink | delivered | đơn vị gốc trong CSV | 30 | 0 | 119 963,03333 | 17 043,15046 | 113 599,01636 | 126 327,05030 |
| EMHR_SF_r0.05_d0.5_near_sink | dropped | đơn vị gốc trong CSV | 30 | 0 | 269 784,50000 | 23 267,95384 | 261 096,10325 | 278 472,89675 |
| EMHR_SF_r0.05_d0.5_near_sink | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 47,23333 | 9,30956 | 43,75709 | 50,70958 |
| EMHR_SF_r0.05_d0.5_near_sink | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 122 842 146,13333 | 17 452 186,06949 | 116 325 392,75514 | 129 358 899,51152 |
| EMHR_SF_r0.05_d0.5_near_sink | TP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | FP | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | TN | đơn vị gốc trong CSV | 30 | 0 | 427,00000 | 0,00000 | 427,00000 | 427,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | FN | đơn vị gốc trong CSV | 30 | 0 | 23,00000 | 0,00000 | 23,00000 | 23,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 271,26667 | 123,97412 | 224,97397 | 317,55936 |
| EMHR_SF_r0.05_d0.5_near_sink | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 47,23333 | 9,30956 | 43,75709 | 50,70958 |
| EMHR_SF_r0.05_d0.5_near_sink | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| EMHR_SF_r0.05_d0.5_near_sink | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.05_d0.5_near_sink | Payload đến sink tại 10.000 giây | Payload nhận (Mbit) | 30 | 0 | 122,18969 | 18,20688 | 115,39113 | 128,98825 |
| SF3_r0.05_d0.5_near_sink | generated_payload_bits | đơn vị gốc trong CSV | 30 | 0 | 406 190 899,20000 | 7 032 384,43382 | 403 564 963,69637 | 408 816 834,70363 |
| SF3_r0.05_d0.5_near_sink | offered_payload_bps | đơn vị gốc trong CSV | 30 | 0 | 40 619,08992 | 703,23844 | 40 356,49637 | 40 881,68347 |
| SF3_r0.05_d0.5_near_sink | jain_forwarding_fairness | đơn vị gốc trong CSV | 30 | 0 | 0,43208 | 0,05668 | 0,41091 | 0,45324 |
| SF3_r0.05_d0.5_near_sink | consumed_energy_j | đơn vị gốc trong CSV | 30 | 0 | 1 236,53477 | 103,20631 | 1 197,99690 | 1 275,07264 |
| SF3_r0.05_d0.5_near_sink | Năng lượng còn lại tại 10.000 giây | Năng lượng sensor (J) | 30 | 0 | 1 013,46523 | 103,20631 | 974,92736 | 1 052,00310 |
| SF3_r0.05_d0.5_near_sink | functional_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 9 923,66667 | 418,09489 | 9 767,54747 | 10 079,78586 |
| SF3_r0.05_d0.5_near_sink | functional_routing_network_death_restricted_s | đơn vị gốc trong CSV | 30 | 0 | 1 651,35627 | 462,16815 | 1 478,77985 | 1 823,93269 |
| SF3_r0.05_d0.5_near_sink | Sensor còn sống tại 10.000 giây | Số sensor còn sống | 30 | 0 | 356,56667 | 12,62915 | 351,85086 | 361,28247 |
| SF3_r0.05_d0.5_near_sink | alive_fraction | đơn vị gốc trong CSV | 30 | 0 | 0,79237 | 0,02806 | 0,78189 | 0,80285 |
| SF3_r0.05_d0.5_near_sink | Lượt đã quan sát sensor đầu tiên chết | Tỷ lệ lượt quan sát FND (%) | 30 | 0 | 100,00000 | 0,00000 | 100,00000 | 100,00000 |
| SF3_r0.05_d0.5_near_sink | generated | đơn vị gốc trong CSV | 30 | 0 | 396 670,80000 | 6 867,56292 | 394 106,40986 | 399 235,19014 |
| SF3_r0.05_d0.5_near_sink | delivered | đơn vị gốc trong CSV | 30 | 0 | 119 325,86667 | 17 780,15206 | 112 686,64877 | 125 965,08456 |
| SF3_r0.05_d0.5_near_sink | dropped | đơn vị gốc trong CSV | 30 | 0 | 277 304,66667 | 22 827,58997 | 268 780,70449 | 285 828,62885 |
| SF3_r0.05_d0.5_near_sink | pending_in_flight | đơn vị gốc trong CSV | 30 | 0 | 40,26667 | 8,60206 | 37,05461 | 43,47873 |
| SF3_r0.05_d0.5_near_sink | received_wire_bits | đơn vị gốc trong CSV | 30 | 0 | 122 189 687,46667 | 18 206 875,71186 | 115 391 128,34466 | 128 988 246,58867 |
| SF3_r0.05_d0.5_near_sink | TP | đơn vị gốc trong CSV | 30 | 0 | 18,53333 | 2,41737 | 17,63067 | 19,43599 |
| SF3_r0.05_d0.5_near_sink | FP | đơn vị gốc trong CSV | 30 | 0 | 45,63333 | 13,02645 | 40,76918 | 50,49749 |
| SF3_r0.05_d0.5_near_sink | TN | đơn vị gốc trong CSV | 30 | 0 | 381,36667 | 13,02645 | 376,50251 | 386,23082 |
| SF3_r0.05_d0.5_near_sink | FN | đơn vị gốc trong CSV | 30 | 0 | 4,46667 | 2,41737 | 3,56401 | 5,36933 |
| SF3_r0.05_d0.5_near_sink | physical_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 345,80000 | 38,78002 | 331,31930 | 360,28070 |
| SF3_r0.05_d0.5_near_sink | routing_reachable_alive | đơn vị gốc trong CSV | 30 | 0 | 40,26667 | 8,60206 | 37,05461 | 43,47873 |
| SF3_r0.05_d0.5_near_sink | Đề xuất cách ly của detector | Số sự kiện trong một lượt | 30 | 0 | 1 586,36667 | 312,70935 | 1 469,59908 | 1 703,13426 |
| SF3_r0.05_d0.5_near_sink | security_reroute_decision_count | đơn vị gốc trong CSV | 30 | 0 | 0,00000 | 0,00000 | 0,00000 | 0,00000 |
| SF3_r0.05_d0.5_near_sink | unique_suspected_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 64,16667 | 13,88148 | 58,98324 | 69,35010 |
| SF3_r0.05_d0.5_near_sink | unique_isolated_by_cutoff | đơn vị gốc trong CSV | 30 | 0 | 64,16667 | 13,88148 | 58,98324 | 69,35010 |

## Bộ biểu đồ

![01_hieu_nang_trung_tam.png](bieu_do/01_hieu_nang_trung_tam.png)

[SVG](bieu_do/01_hieu_nang_trung_tam.svg) · [CSV nguồn](bieu_do/01_hieu_nang_trung_tam_du_lieu.csv)

![02_trang_thai_10000s.png](bieu_do/02_trang_thai_10000s.png)

[SVG](bieu_do/02_trang_thai_10000s.svg) · [CSV nguồn](bieu_do/02_trang_thai_10000s_du_lieu.csv)

![03_phat_hien_bao_mat.png](bieu_do/03_phat_hien_bao_mat.png)

[SVG](bieu_do/03_phat_hien_bao_mat.svg) · [CSV nguồn](bieu_do/03_phat_hien_bao_mat_du_lieu.csv)

![04_ty_le_attacker.png](bieu_do/04_ty_le_attacker.png)

[SVG](bieu_do/04_ty_le_attacker.svg) · [CSV nguồn](bieu_do/04_ty_le_attacker_du_lieu.csv)

![05_xac_suat_bo_goi.png](bieu_do/05_xac_suat_bo_goi.png)

[SVG](bieu_do/05_xac_suat_bo_goi.svg) · [CSV nguồn](bieu_do/05_xac_suat_bo_goi_du_lieu.csv)

![06_vi_tri_attacker.png](bieu_do/06_vi_tri_attacker.png)

[SVG](bieu_do/06_vi_tri_attacker.svg) · [CSV nguồn](bieu_do/06_vi_tri_attacker_du_lieu.csv)

![07_dien_bien_mang.png](bieu_do/07_dien_bien_mang.png)

[SVG](bieu_do/07_dien_bien_mang.svg) · [CSV nguồn](bieu_do/07_dien_bien_mang_du_lieu.csv)

![08_FND_gioi_han.png](bieu_do/08_FND_gioi_han.png)

[SVG](bieu_do/08_FND_gioi_han.svg) · [CSV nguồn](bieu_do/08_FND_gioi_han_du_lieu.csv)

![09_trang_thai_goi.png](bieu_do/09_trang_thai_goi.png)

[SVG](bieu_do/09_trang_thai_goi.svg) · [CSV nguồn](bieu_do/09_trang_thai_goi_du_lieu.csv)

![10_doi_tuyen_va_cach_ly.png](bieu_do/10_doi_tuyen_va_cach_ly.png)

[SVG](bieu_do/10_doi_tuyen_va_cach_ly.svg) · [CSV nguồn](bieu_do/10_doi_tuyen_va_cach_ly_du_lieu.csv)

## Nguồn và tái tạo

Model SHA256: `55bb401bac0456e8c1ca5e91efdb98f03395a82338da583450ea84998ee824a8`. Plan hash: `718723decc7cbd4e5d0e748a33da94380a66b89e9b6e829779c2854ee4d30f05`. Batch gốc: `F:\bangdzaihjhj\dancctt\results\security_10000s\evaluation_10000s_20261116T080007575200Z_8703eee0`. [Cấu hình](experiment_10000s.json), [plan](plan.json), [protocol hiệu lực](protocol_effective.json) · [protocol gốc](protocol.json), [provenance](analysis_provenance.json), [manifest nguồn](input_manifest.json), [hướng dẫn tái tạo](TAI_TAO.md).
