# Tái tạo nghiên cứu 10.000 giây

Giữ Python và các phiên bản trong manifest. Dự án mô phỏng: `F:\bangdzaihjhj\dancctt`. Lõi và detector phải khớp source_snapshot.zip/frozen lock trước khi chạy.

```powershell
Set-Location 'F:\bangdzaihjhj\dancctt'
& '.\.venv\Scripts\python.exe' -B -X utf8 analysis\security_10000s\study.py dry-run --project .
& '.\.venv\Scripts\python.exe' -B -X utf8 -m pytest -q -p no:cacheprovider analysis\security_10000s\test_profile.py
& '.\.venv\Scripts\python.exe' -B -X utf8 analysis\security_10000s\study.py run --project . --output results\security_10000s --workers 10
```

Lệnh run tạo batch mới 480 lượt, không ghi đè dữ liệu. Dùng đường dẫn batch vừa in cho report. Với batch hiện tại:

```powershell
& '.\.venv\Scripts\python.exe' -B -X utf8 analysis\security_10000s\study.py status --project . --batch 'F:\bangdzaihjhj\dancctt\results\security_10000s\evaluation_10000s_20261116T080007575200Z_8703eee0'
& '.\.venv\Scripts\python.exe' -B -X utf8 analysis\security_10000s\study.py resume --project . --batch 'F:\bangdzaihjhj\dancctt\results\security_10000s\evaluation_10000s_20261116T080007575200Z_8703eee0' --workers 10
& '.\.venv\Scripts\python.exe' -B -X utf8 analysis\security_10000s\report_vi.py 'F:\bangdzaihjhj\dancctt\results\security_10000s\evaluation_10000s_20261116T080007575200Z_8703eee0' --project . --output results\security_10000s_reports --pack-data
& '.\.venv\Scripts\python.exe' -B -X utf8 analysis\security_10000s\verify_report.py 'F:\bangdzaihjhj\dancctt\results\security_10000s\evaluation_10000s_20261116T080007575200Z_8703eee0' 'F:\bangdzaihjhj\dancctt\results\security_10000s_reports\bao_cao_10000s_20261116T104239277960Z_7d4384f3' --project .
```

Resume chỉ bỏ qua lượt COMPLETE có hash hợp lệ. Không chạy unit test đồng thời với batch. Muốn chỉ vẽ lại, gọi report trên batch hoàn tất; không cần chạy lại 480 lượt. Bộ ZIP chứa raw/<run_id>/, báo cáo, CSV, ảnh, script phân tích và source_snapshot.zip. Đường dẫn tuyệt đối trong checkpoint/manifest giữ làm bằng chứng nơi đo gốc; portable_run_index.json ánh xạ từng run_id tới raw trong ZIP. Không sửa hash/lock để chuyển thư mục hoặc đổi profile. Kiểm tra hash bằng package_inventory.json. verification.json bên trong ZIP ghi pha kiểm tra trước khi đóng ZIP; verification.json bên cạnh ZIP ghi thêm kết quả kiểm tra gói và SHA256 của chính ZIP để tránh vòng lặp tự băm.

Các mốc chết NA/censored giữ nguyên; CI95 nằm trong bảng/CSV. Ảnh không có error bar, phụ đề cấu hình hoặc ghi chú cuối hình. Các kết quả dài hạn giữ riêng trong results/requested và results/requested_reports.
