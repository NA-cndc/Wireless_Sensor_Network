# Nghiên cứu WSN trong 10.000 giây

Profile `WSN_SECURITY_FIXED_HORIZON_10000S_V1` tạo 16 cấu hình OFAT × 30 seed = 480 lượt EVALUATION_FIXED_HORIZON_10000S. Giữ lõi mô phỏng và detector đã khóa; không dùng pilot/test để lách kiểm tra. Mỗi lượt giữ 450 sensor, 7 sink, E0=5 J, Eth=1 J, R=300 m, payload=wire=128 byte, Tg=10 s, p_channel=0,01. Khác cấu hình dài hạn ở max_rounds=1000 và config_profile=CUSTOM; profile đánh giá chính thức nằm trong plan/protocol/job scope.

```powershell
Set-Location 'F:\bangdzaihjhj\dancctt'
& '.\.venv\Scripts\python.exe' -B -X utf8 analysis\security_10000s\study.py dry-run --project .
& '.\.venv\Scripts\python.exe' -B -X utf8 -m pytest -q -p no:cacheprovider analysis\security_10000s\test_profile.py
& '.\.venv\Scripts\python.exe' -B -X utf8 analysis\security_10000s\study.py run --project . --output results\security_10000s --workers 10
```

Dùng đường dẫn batch mới in để tạo báo cáo:

```powershell
& '.\.venv\Scripts\python.exe' -B -X utf8 analysis\security_10000s\report_vi.py 'DUONG_DAN_BATCH_MOI' --project . --output results\security_10000s_reports --pack-data
& '.\.venv\Scripts\python.exe' -B -X utf8 analysis\security_10000s\verify_report.py 'DUONG_DAN_BATCH_MOI' 'DUONG_DAN_BAO_CAO_MOI' --project .
```

`study.py prepare` chỉ tạo plan; `resume --batch ...` tiếp tục hoặc kiểm tra batch cũ; `status --batch ...` đọc tiến độ. Mỗi lần report tạo thư mục riêng, không ghi đè checkpoint dài hạn. Không chạy unit test đồng thời với batch. Bộ ZIP chứa đủ raw 480 lượt, source snapshot, script và bảng kiểm kê SHA256. `portable_run_index.json` ánh xạ đường dẫn raw trong ZIP; đường dẫn tuyệt đối trong manifest giữ nguyên nơi đo ban đầu.

Cutoff: xử lý mọi sự kiện t≤10.000 theo thứ tự SimPy, không xả gói sau thời điểm chốt. Sinh gói mỗi 10 s từ t=10 đến t=10.000; gói chưa kết thúc giữ pending_in_flight, không tính mất hoặc thành công. Test kiểm tra cả arrival đúng t=10.000 lẫn arrival sau cutoff. Detector chỉ dùng quan sát đến cutoff; thời hạn cách ly đã lên lịch có thể ở tương lai và không được coi là sự kiện đã quan sát.

HND/LND chưa đạt giữ NA/censored và chuyển vào bảng n_observed/n_runs; hình chính dùng payload, sensor sống và năng lượng còn lại tại 10.000 s. FND giới hạn là min(T,10.000), không coi cap là thời điểm chết thật. Mean/std mẫu ddof=1/CI95 Student-t tính theo seed; matched-seed contrasts có paired t, Wilcoxon-Pratt và Holm toàn họ. CSV giữ số đầy đủ và NA. Chi phí idle/MAC/ACK/giám sát/điều khiển chưa mô phỏng giữ NA.

`charts_vi.py` xuất 10 hình PNG/SVG kèm CSV và manifest: số mean trên cột, không error bar; không phụ đề cấu hình và không ghi chú cuối hình; legend ngoài vùng dữ liệu. Kiểm tra kích thước chữ/nhãn khi render và đối chiếu cột/CSV. `verify_report.py` kiểm tra hash từng lượt, packet/energy conservation, cutoff, classification, death ranks, thống kê, pairing, SVG, liên kết và ZIP. Đối chiếu mẫu t=10.000 với checkpoint dài hạn chỉ là kiểm chứng độc lập; không đưa chỉ số dài hạn vào báo cáo mới.

Phạm vi ngắn hạn này được chọn sau khi người dùng xem dữ liệu dài hạn. Giữ tất cả seed và kết quả bất lợi; không tinh chỉnh detector bằng evaluation. Kết quả 10.000 s không chứng minh đầy đủ tuổi thọ dài hạn.


## Kiểm tra cột và phạm vi mới

Giới hạn hiệu lực là 10.000 s/1.000 round. Chuỗi thời gian lấy mẫu 100 s; traffic vẫn mỗi 10 s và các mốc chết theo đúng thời điểm sự kiện. Kết quả 1.000 s và 100.000 s cũ giữ nguyên. Nghiên cứu này là phạm vi điều chỉnh theo yêu cầu, không tuyên bố thay thế đầy đủ horizon 100.000 s của kế hoạch gốc.

Cột có giá trị 0 có nhãn và vòng tròn ở đường gốc, không tạo chiều cao giả. Mean chưa xác định trong các hình chính làm renderer dừng để kiểm tra; HND/LND thiếu quan sát chuyển vào bảng NA/censored. Mỗi cột dương được đo chiều cao pixel sau render; giá trị nhỏ dưới hai pixel có điểm đánh dấu đúng tọa độ. bar_visibility_audit.csv và figure_manifest.json lưu nguồn mean/unit/n_used, trạng thái positive/zero và kết quả kiểm tra hình học.

Hình 10 chỉ vẽ đề xuất cách ly của hai nhóm có detector, không vẽ bốn nhóm detector tắt thành các cột khó hiểu. SF-2 vẫn không tránh relay. CSV giữ số đề xuất, số node khác nhau từng bị gắn cờ, chế độ tránh relay và số quyết định tìm lại tuyến với nguyên nhân chính security lấy trực tiếp từ log. Không lấy số đề xuất làm số lần đổi tuyến hay số attacker duy nhất.

relay_security_per_seed.csv ghi trạng thái từng relay tại cutoff. FR tích lũy trong bảng có tên rõ ràng; không coi đó là FR cửa sổ dùng cập nhật EWMA. full_trace=false nên không tuyên bố lưu toàn bộ lịch sử từng gói/cửa sổ. Metadata protocol_effective.json đính chính một chuỗi mô tả cutoff của mẫu cũ; plan/job/completion hash gốc không bị thay. Cấu hình thực và số đo luôn 10.000 s.
